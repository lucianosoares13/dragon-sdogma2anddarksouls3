﻿#Requires -Version 5.1
<#
.SYNOPSIS
Instala somente tres Lua de diagnostico, usando o loader que voce ja possui.
.EXAMPLE
.\tools\install-runtime-test.ps1 -WhatIf
.EXAMPLE
.\tools\install-runtime-test.ps1 -GamePath 'D:\Games\Dragons Dogma 2'
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$GamePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageId = 'dogma-of-ash-runtime-install/v1'
$hostExeHash = '29cbb3db102a8c8dba749f608928573e17d85fd9bdbaf3043abeccf911b0a836'
$existingLoaderHash = '8f005288fb1cded7c36dc834480125a824b3946b075caf15557e06d524d753bd'
$relativeFiles = @(
    'reframework/autorun/dogma_of_ash.lua',
    'reframework/autorun/dogma_of_ash/host.lua',
    'reframework/autorun/dogma_of_ash/domain.lua'
)
$receiptRelative = 'reframework/data/dogma_of_ash/runtime-install-receipt.json'

function Get-SteamLibraries {
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            foreach ($property in @('SteamPath', 'InstallPath')) {
                $value = $item.PSObject.Properties[$property]
                if ($null -ne $value -and $value.Value) { [void]$roots.Add([string]$value.Value) }
            }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { [void]$roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        [void]$libraries.Add([IO.Path]::GetFullPath($root))
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        $content = Get-Content -Raw -LiteralPath $vdf
        foreach ($match in [regex]::Matches($content, '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
            $candidate = $match.Groups['path'].Value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                [void]$libraries.Add([IO.Path]::GetFullPath($candidate))
            }
        }
    }
    foreach ($library in $libraries) { $library }
}

function Find-SteamInstall([string]$AppId) {
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($library in @(Get-SteamLibraries)) {
        $manifest = Join-Path $library ('steamapps/appmanifest_{0}.acf' -f $AppId)
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        $match = [regex]::Match((Get-Content -Raw -LiteralPath $manifest), '"installdir"\s+"(?<dir>[^"\r\n]+)"')
        if (-not $match.Success) { continue }
        $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
        $candidate = [IO.Path]::GetFullPath((Join-Path $common $match.Groups['dir'].Value))
        if (-not $candidate.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { continue }
        if (Test-Path -LiteralPath $candidate -PathType Container) { [void]$found.Add($candidate) }
    }
    foreach ($path in $found) { $path }
}

function Get-BytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Assert-SafeTarget([string]$Root, [string]$Target) {
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $Target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destino fora do diretorio do DD2.' }
    $cursor = $Target
    while ($cursor -ne $Root) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -Force -LiteralPath $cursor
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link/junction no destino: $cursor. Nenhum arquivo sera sobrescrito." }
            if ($cursor -ne $Target -and -not $item.PSIsContainer) { throw "Um arquivo ocupa o diretorio necessario: $cursor" }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
        if (-not $cursor) { throw 'Destino invalido.' }
    }
}

if ($env:OS -ne 'Windows_NT') { throw 'Execute este instalador no Windows, no computador que possui Dragon''s Dogma 2.' }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Feche Dragon''s Dogma 2 antes de instalar.' }

if (-not $GamePath) {
    $candidates = @(Find-SteamInstall '2054970' | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'DD2.exe') -PathType Leaf })
    if ($candidates.Count -ne 1) { throw 'Nao foi encontrada uma unica instalacao Steam do DD2. Informe -GamePath apontando para a pasta de DD2.exe.' }
    $GamePath = $candidates[0]
}
$hostRoot = (Resolve-Path -LiteralPath $GamePath).ProviderPath.TrimEnd([IO.Path]::DirectorySeparatorChar)
$hostExe = Join-Path $hostRoot 'DD2.exe'
if (-not (Test-Path -LiteralPath $hostExe -PathType Leaf)) { throw '-GamePath deve apontar para a pasta de DD2.exe.' }
if (((Get-Item -Force -LiteralPath $hostRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Junction/link na pasta do jogo. Nenhum arquivo foi instalado.' }
Assert-SafeTarget $hostRoot $hostExe

$bundleRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $bundleRoot 'manifest.json'
try { $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json }
catch { throw 'Manifesto do pacote ausente ou invalido. Nada foi instalado.' }
if ($manifest.schema -ne 'dogma-of-ash-runtime-package/v1' -or $manifest.hostExeSha256 -ine $hostExeHash -or $manifest.existingLoaderSha256 -ine $existingLoaderHash) { throw 'Manifesto nao corresponde a este teste e seus hashes fixos. Nada foi instalado.' }
$loaderPath = Join-Path $hostRoot 'dinput8.dll'
Assert-SafeTarget $hostRoot $loaderPath
if (-not (Test-Path -LiteralPath $loaderPath -PathType Leaf)) { throw 'O loader existente nao foi encontrado. Este pacote nao instala DLLs.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $hostExe).Hash -ine $hostExeHash) { throw 'DD2.exe difere da versao observada. Nenhum arquivo foi instalado; envie um novo diagnostico.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $loaderPath).Hash -ine $existingLoaderHash) { throw 'dinput8.dll difere do loader observado. Ele foi preservado; nenhum arquivo foi instalado.' }
$entries = @(
    foreach ($relative in $relativeFiles) {
        $sourceRelative = $relative
        $source = Join-Path $bundleRoot $sourceRelative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Bundle incompleto: $sourceRelative. Use o pacote completo." }
        $bytes = [IO.File]::ReadAllBytes($source)
        if ($bytes.Length -eq 0) { throw "Arquivo vazio no bundle: $sourceRelative" }
        $hash = Get-BytesHash $bytes
        $expected = $manifest.files.PSObject.Properties[$relative]
        if ($null -eq $expected -or $expected.Value -notmatch '^[0-9a-fA-F]{64}$' -or $hash -ine $expected.Value) { throw ('SHA-256 do Lua nao corresponde ao manifesto: ' + $relative) }
        [pscustomobject]@{ path = $relative; hash = $hash; bytes = $bytes; destination = [IO.Path]::GetFullPath((Join-Path $hostRoot $relative)); exists = $false }
    }
)

$receiptPath = [IO.Path]::GetFullPath((Join-Path $hostRoot $receiptRelative))
Assert-SafeTarget $hostRoot $receiptPath
$previousReceipt = $null
$previousHash = $null
$owned = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
if (Test-Path -LiteralPath $receiptPath) {
    if (-not (Test-Path -LiteralPath $receiptPath -PathType Leaf)) { throw 'Um diretorio ocupa o caminho do recibo.' }
    $receiptBytes = [IO.File]::ReadAllBytes($receiptPath)
    $previousHash = Get-BytesHash $receiptBytes
    try { $previousReceipt = [Text.Encoding]::UTF8.GetString($receiptBytes) | ConvertFrom-Json }
    catch { throw 'Recibo existente invalido. Preserve-o e revise manualmente; a instalacao nao o sobrescrevera.' }
    if ($previousReceipt.schema -ne $packageId -or -not ($previousReceipt.files -is [array])) { throw 'Recibo existente nao reconhecido. Nenhum arquivo sera sobrescrito.' }
    foreach ($file in $previousReceipt.files) {
        if ($relativeFiles -cnotcontains $file.path -or $file.sha256 -notmatch '^[0-9a-fA-F]{64}$' -or $owned.ContainsKey($file.path)) { throw 'Recibo existente contem entradas desconhecidas.' }
        $expected = @($entries | Where-Object { $_.path -ceq $file.path })[0]
        if ($expected.hash -ine $file.sha256) { throw 'Recibo pertence a outra versao do pacote. Preserve a instalacao e revise antes de trocar a versao.' }
        $owned.Add($file.path, $file.sha256)
    }
}

# Examine todos os conflitos antes de criar qualquer arquivo.
$conflicts = @(
    foreach ($entry in $entries) {
        Assert-SafeTarget $hostRoot $entry.destination
        if (Test-Path -LiteralPath $entry.destination) {
            $entry.exists = $true
            if (-not (Test-Path -LiteralPath $entry.destination -PathType Leaf)) { $entry.path; continue }
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ine $entry.hash) { $entry.path }
        }
    }
)
if ($conflicts.Count -gt 0) {
    throw ('Conteudo diferente ja existe: ' + ($conflicts -join ', ') + '. Nada foi copiado. Preserve seus mods; este instalador nao os substitui.')
}

$missing = @($entries | Where-Object { -not $_.exists })
Write-Host ('Host validado: DD2; versao ' + [Diagnostics.FileVersionInfo]::GetVersionInfo($hostExe).FileVersion)
Write-Host 'Hashes do DD2 e do loader existente conferidos. Nenhuma DLL sera instalada ou substituida.'
Write-Host ('Arquivos novos: ' + $missing.Count + '; arquivos identicos existentes: ' + ($entries.Count - $missing.Count) + '.')
if ($missing.Count -eq 0 -and $previousReceipt) { Write-Host 'Instalacao identica ja existe. Nenhuma alteracao necessaria.'; return }
if (-not $PSCmdlet.ShouldProcess($hostRoot, 'Instalar diagnostico DD2 e registrar somente arquivos criados')) { return }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'DD2 foi iniciado durante a verificacao. Feche o jogo e tente novamente.' }

$created = [Collections.Generic.List[object]]::new()
$temporaryLua = [Collections.Generic.List[string]]::new()
$temporaryReceipt = $null
$committed = $false
try {
    foreach ($entry in $missing) {
        Assert-SafeTarget $hostRoot $entry.destination
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($entry.destination))
        $temporaryPath = $entry.destination + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
        Assert-SafeTarget $hostRoot $temporaryPath
        $stream = [IO.File]::Open($temporaryPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $temporaryLua.Add($temporaryPath)
        try { $stream.Write($entry.bytes, 0, $entry.bytes.Length); $stream.Flush() }
        finally { $stream.Dispose() }
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temporaryPath).Hash -ine $entry.hash) { throw 'Falha ao verificar o Lua temporario. Instalacao cancelada.' }
        Assert-SafeTarget $hostRoot $entry.destination
        [IO.File]::Move($temporaryPath, $entry.destination)
        [void]$temporaryLua.Remove($temporaryPath)
        $created.Add($entry)
        $owned[$entry.path] = $entry.hash
    }
    $receipt = [ordered]@{
        schema = $packageId
        installedAtUtc = [DateTime]::UtcNow.ToString('o')
        hostExeSha256 = $hostExeHash
        existingLoaderSha256 = $existingLoaderHash
        files = @(
            foreach ($relative in $relativeFiles) {
                if ($owned.ContainsKey($relative)) { [ordered]@{ path = $relative; sha256 = $owned[$relative] } }
            }
        )
    }
    Assert-SafeTarget $hostRoot $receiptPath
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($receiptPath))
    $temporaryReceipt = $receiptPath + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    [IO.File]::WriteAllText($temporaryReceipt, ($receipt | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
    if ($previousReceipt) {
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash -ine $previousHash) { throw 'O recibo mudou durante a instalacao. Operacao cancelada.' }
        [IO.File]::Replace($temporaryReceipt, $receiptPath, $null)
    } else { [IO.File]::Move($temporaryReceipt, $receiptPath) }
    $temporaryReceipt = $null
    $committed = $true
} finally {
    foreach ($temporaryPath in $temporaryLua) {
        if (Test-Path -LiteralPath $temporaryPath -PathType Leaf) {
            Assert-SafeTarget $hostRoot $temporaryPath
            Remove-Item -LiteralPath $temporaryPath
        }
    }
    if ($temporaryReceipt -and (Test-Path -LiteralPath $temporaryReceipt -PathType Leaf)) { Remove-Item -LiteralPath $temporaryReceipt }
    if (-not $committed) {
        foreach ($entry in $created) {
            if ((Test-Path -LiteralPath $entry.destination -PathType Leaf) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ieq $entry.hash) { Remove-Item -LiteralPath $entry.destination }
        }
    }
}
Write-Host 'Diagnostico instalado. Inicie DD2 normalmente; o pacote nao altera saves, atributos, lojas, combate ou assets.'
Write-Host 'Para remover: execute tools\remove-runtime-test.ps1 com o mesmo -GamePath, se utilizado.'
