# Testar a integração dentro do DD2

Este pacote instala somente scripts Lua de diagnóstico para o loader que já
existe no seu PC. Ainda não habilita combate, equipamentos ou evolução por ouro.

1. Feche Dragon's Dogma 2. Extraia todos os arquivos do ZIP em uma nova pasta.
2. Abra **instalar-teste-runtime.cmd**. Aguarde a mensagem de conclusão.
3. Abra DD2 normalmente e carregue uma partida com seu peão principal.
4. Aperte **Insert**, abra **Script Generated UI** e expanda
   **Dogma das Cinzas — diagnóstico experimental**.
5. Clique em **Capturar diagnóstico** e depois em **Exportar diagnóstico**.
6. Na pasta em que extraiu o ZIP, abra **recolher-teste-runtime.cmd**.
   Envie **diagnostico-runtime.json**, criado nessa mesma pasta.

Não é necessário abrir Dark Souls III. Pode fechar as janelas do iniciador
pressionando uma tecla depois de ler a mensagem de conclusão.
Se aparecer um erro ou o painel não aparecer, envie uma foto da mensagem.

## Retirar este teste

Feche DD2 e execute **retirar-teste-runtime.cmd** na mesma pasta do pacote.
Ele remove somente scripts que o instalador criou e que permanecem iguais.
Arquivos preexistentes ou modificados e relatórios gerados são preservados.

## Alcance

O instalador confere os hashes do executável e do loader analisados nesta
conversa. Se algum deles mudou, interrompe a instalação para nova análise.
Ele preserva o `dinput8.dll` existente e os outros mods.

Os scripts consultam tipos, assinaturas e a presença do Nascen e do peão.
Não aplicam hooks de XP, alterações de ouro, atributos, lojas ou saves.
O relatório contém esses metadados; não inclui nomes dos jogadores,
endereços de memória, caminhos completos ou os arquivos de save.

O iniciador usa a mesma correção temporária do PowerShell do diagnóstico
anterior: verifica o hash do script e aplica `RemoteSigned` somente naquele
processo. Políticas definidas pelo administrador continuam sendo respeitadas.

Os testes feitos na nuvem verificam os scripts e a preservação dos arquivos.
A execução deste procedimento no seu PC é necessária para verificar a API
real da expansão. Ela ainda não comprova as funcionalidades do mashup.
