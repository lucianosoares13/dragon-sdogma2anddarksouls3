-- SPDX-License-Identifier: MIT
-- Read-only DD2 diagnostic adapter. It deliberately has no gameplay hooks or
-- transaction adapter: SDK presence is not proof that a mutation is safe.
-- Proven getters (pinned source, not a promise of compatibility with a patch):
-- https://github.com/kagenocookie/dd2-content-editor/blob/eabf3fc228eecbe5bff8a3a1f0d62384f84e51cd/dd2/editors/core/utils.lua#L43-L49
-- https://github.com/alphazolam/Skill-Maker/blob/b9d5d51e369dc19873adfb05eb7967e53388b403/reframework/autorun/SkillMaker.lua#L6527
-- Additional named serialization metadata (not callable transaction APIs):
-- https://github.com/kagenocookie/dd2-content-editor/blob/eabf3fc228eecbe5bff8a3a1f0d62384f84e51cd/dd2/rsz/dd2.json
-- Candidate metadata type names from upstream schema; never invoked:
-- https://github.com/alphazolam/RE_RSZ/blob/main/rszdd2.json
-- Focused XP/stat/money candidates, descriptor-only (not live balance proof):
-- https://github.com/alphazolam/RE_RSZ/blob/341315800102f0db5f58a2ccfd9d74cfa8ae731c/rszdd2.json
-- CorpseController selectors are descriptor-only, not death-event hooks:
-- https://github.com/alphazolam/Skill-Maker/blob/b9d5d51e369dc19873adfb05eb7967e53388b403/reframework/autorun/SkillMaker.lua#L6751
-- XP/item selectors are candidates for future research and are NEVER called:
-- https://github.com/alphazolam/Skill-Maker/blob/b9d5d51e369dc19873adfb05eb7967e53388b403/reframework/autorun/SkillMaker.lua#L6651
-- https://github.com/kagenocookie/dd2-content-editor/blob/eabf3fc228eecbe5bff8a3a1f0d62384f84e51cd/dd2/editors/devtools.lua#L134-L139
-- SDK reflection and JSON persistence:
-- https://github.com/praydog/REFramework/blob/v1.5.9.1/src/mods/bindings/Sdk.cpp#L1508-L1641
-- https://github.com/praydog/REFramework/blob/v1.5.9.1/src/mods/bindings/Json.cpp#L141-L165
-- APIs also checked against the installed-loader commit reported by the user:
-- https://github.com/praydog/REFramework/blob/0a07faae46a6fc1c51cd1699a0cf99a3f9c2679f/src/mods/bindings/Sdk.cpp#L1670
-- TDB version is observed metadata; it does not establish game-build support.

local Host = {}
Host.__index = Host
Host.DIAGNOSTIC_PATH = "dogma_of_ash/diagnostics.json"

local FEATURES = {
    { key = "xp", label = "XP do Nascen", reason = "Falta validar o caminho de ganho de XP exclusivo do Nascen; o peão deve manter a progressão normal." },
    { key = "drops", label = "Drops de ouro", reason = "Faltam evento de morte única, identidade estável do inimigo e crédito de ouro validados no jogo." },
    { key = "levels", label = "Evolução por ouro na guilda", reason = "Faltam contexto da guilda, cálculo nativo de atributos e transação atômica de ouro, nível e save." },
    { key = "combat", label = "Combate e esquivas de DS3", reason = "Faltam animações convertidas, controle de ações e validação no jogo." },
    { key = "items", label = "Armas e armaduras nas lojas", reason = "Faltam catálogo DS3 completo, assets convertidos e IDs das lojas de Vernworth validados." },
    { key = "spells", label = "Magias e feitiços na guilda", reason = "Faltam catálogo DS3 com DLCs, ações e efeitos convertidos e integração da guilda sem restrição de vocação." },
}

-- These are evidenced by the two upstream projects. Candidate members are
-- exported as names/signatures only and are NEVER invoked.
local TYPE_SPECS = {
    { name = "app.CharacterManager", methods = { "get_ManualPlayer", "getCharacterExp(app.Character)" } },
    { name = "app.PawnManager", methods = { "get_MainPawn" } },
    { name = "app.Character", methods = { "get_Human", "get_Context" } },
    { name = "app.Human", methods = { "get_StatusContext" } },
    { name = "app.HumanStatusContext", fields = { "_Level", "_Exp", "_IncreaseParams" } },
    { name = "app.IncreaseStatus", fields = {
        "_HitPoint", "_Stamina", "_Attack", "_Defence", "_MagicAttack", "_MagicDefence", "_Weight", "_Blow",
        "IsCapHitPoint", "IsCapStamina", "IsCapAttack", "IsCapDefence", "IsCapMagicAttack", "IsCapMagicDefence", "IsCapWeight", "IsCapBlow",
    } },
    { name = "app.JobContext", fields = { "CurrentJob", "CulmativeExp", "ConsumableExp" } },
    { name = "app.CharacterExperiencePointsTable", fields = { "ExpDataList", "QuestExpDataList", "PlayerAdjustData", "MainPawnAdjustData" } },
    { name = "app.ExpDispenser", all_members = true },
    { name = "app.ExpDispenser.ExpGranter", all_members = true },
    { name = "app.ExpDispenser.ExpRecipient", all_members = true },
    { name = "app.ExpDispenser.ExpRecipient.BeforeAddExpAndJobPoint", all_members = true },
    { name = "app.ExpDispenser.ExpRecipient.BeforeCalcJobPoint", all_members = true },
    { name = "app.CalcCharaStatus", all_members = true },
    { name = "app.ItemManager.MoneyBackup", fields = { "_Gold", "_Rim" }, all_members = true },
    { name = "app.ItemManager.GameSaveData", fields = { "MoneySave" } },
    { name = "app.CorpseController", methods = { "setCorpseStep", "get_Chara" } },
    { name = "app.ItemManager", methods = { "getItem(System.Int32, System.Int32, app.CharacterID)" }, fields = { "ShopParamTable" } },
    { name = "app.ItemShopParam", fields = { "_ShopId", "_BuyParams" } },
    { name = "app.ItemShopBuyParam", fields = {} },
    { name = "app.ItemDataParam", fields = {} },
    { name = "app.ItemWeaponParam", fields = { "_WeaponId" } },
    { name = "app.ItemArmorParam", fields = {} },
    { name = "app.HumanStaminaController", methods = { "Chara_OnConsumeStaminaHandler" } },
    { name = "app.ActionManager", methods = { "requestActionCore(app.ActionManager.Priority, System.String, System.UInt32)" } },
}

local RELEVANT = {
    "exp", "level", "money", "gold", "status", "dead", "death", "died",
    "kill", "stamina", "skill", "magic", "magick", "job", "equip", "shop",
    "save", "pawn", "manualplayer", "cachedcharacter", "context", "action",
    "increase", "cap", "blow", "weight", "dcp", "vocation",
}

local function call_member(object, name, ...)
    if object == nil then return false, nil end
    local args = table.pack(...)
    return pcall(function()
        local fn = object[name]
        if type(fn) ~= "function" then error("unavailable") end
        return fn(object, table.unpack(args, 1, args.n))
    end)
end

local function call_function(object, name, ...)
    if object == nil then return false, nil end
    local args = table.pack(...)
    return pcall(function()
        local fn = object[name]
        if type(fn) ~= "function" then error("unavailable") end
        return fn(table.unpack(args, 1, args.n))
    end)
end

local function has_function(object, name)
    local ok, member = pcall(function() return object and object[name] end)
    return ok and type(member) == "function"
end

local function type_name(definition)
    local ok, name = call_member(definition, "get_full_name")
    return ok and type(name) == "string" and name or "unknown"
end

local function relevant(name)
    if type(name) ~= "string" then return false end
    local lower = name:lower()
    for _, token in ipairs(RELEVANT) do
        if lower:find(token, 1, true) then return true end
    end
    return false
end

-- REFramework exposes std::vector via sol userdata. ipairs works on the
-- container; a table-only test would incorrectly erase SDK parameter types.
local function sequence(container)
    if container == nil then return false, {} end
    local result = {}
    local ok = pcall(function()
        for index, value in ipairs(container) do
            if index > 4096 then error("oversized_container") end
            result[#result + 1] = value
        end
    end)
    return ok, ok and result or {}
end

local function method_description(method)
    local _, name = call_member(method, "get_name")
    local _, count = call_member(method, "get_num_params")
    local _, param_types = call_member(method, "get_param_types")
    local _, return_type = call_member(method, "get_return_type")
    local static_verified, is_static = call_member(method, "is_static")
    local parameters_available, parameter_values = sequence(param_types)
    local parameters = {}
    for _, param in ipairs(parameter_values) do parameters[#parameters + 1] = type_name(param) end
    local safe_name = type(name) == "string" and name or "unknown"
    return {
        name = safe_name,
        signature = safe_name .. "(" .. table.concat(parameters, ", ") .. ")",
        parameter_count = type(count) == "number" and count or -1,
        parameter_types = parameters,
        parameter_types_available = parameters_available,
        return_type = type_name(return_type),
        is_static = is_static == true,
        static_metadata_available = static_verified and type(is_static) == "boolean",
    }
end

local function field_description(field)
    local _, name = call_member(field, "get_name")
    local _, field_type = call_member(field, "get_type")
    local _, is_static = call_member(field, "is_static")
    return {
        name = type(name) == "string" and name or "unknown",
        type = type_name(field_type),
        is_static = is_static == true,
    }
end

local function add_missing(snapshot, kind, owner, member)
    snapshot.missing[#snapshot.missing + 1] = {
        kind = kind, type = owner, member = member or "",
    }
end

local function describe_type(snapshot, definition, spec)
    local result = {
        name = spec.name, present = definition ~= nil,
        required_methods = {}, required_fields = {}, methods = {}, fields = {},
        descriptors_only = true, truncated = false,
    }
    snapshot.types[#snapshot.types + 1] = result
    if not definition then
        add_missing(snapshot, "type", spec.name)
        return
    end
    for _, name in ipairs(spec.methods or {}) do
        local ok, method = call_member(definition, "get_method", name)
        local entry = { selector = name, present = ok and method ~= nil }
        if entry.present then entry.descriptor = method_description(method)
        else add_missing(snapshot, "method", spec.name, name) end
        result.required_methods[#result.required_methods + 1] = entry
    end
    for _, name in ipairs(spec.fields or {}) do
        local ok, field = call_member(definition, "get_field", name)
        local entry = { selector = name, present = ok and field ~= nil }
        if entry.present then entry.descriptor = field_description(field)
        else add_missing(snapshot, "field", spec.name, name) end
        result.required_fields[#result.required_fields + 1] = entry
    end
    for _, pair in ipairs({ { "get_methods", "methods", method_description }, { "get_fields", "fields", field_description } }) do
        local ok, members = call_member(definition, pair[1])
        local iterable, values = sequence(members)
        if ok and iterable then
            for _, member in ipairs(values) do
                local _, name = call_member(member, "get_name")
                if spec.all_members or relevant(name) then
                    if #result[pair[2]] < 160 then
                        result[pair[2]][#result[pair[2]] + 1] = pair[3](member)
                    else result.truncated = true end
                end
            end
            table.sort(result[pair[2]], function(a, b)
                return (a.signature or a.name) < (b.signature or b.name)
            end)
        else
            add_missing(snapshot, "reflection", spec.name, pair[1])
        end
    end
end

-- The ONLY native calls below are known upstream no-argument read getters.
-- Parameter, return and instance checks fail closed when SDK metadata differs.
local function read_getter(snapshot, object, selector)
    if object == nil then return nil, "instance_not_loaded" end
    local ok, definition = call_member(object, "get_type_definition")
    if not ok or not definition then return nil, "type_unavailable" end
    local owner = type_name(definition)
    local found, method = call_member(definition, "get_method", selector)
    if not found or not method then
        add_missing(snapshot, "method", owner, selector)
        return nil, "method_missing"
    end
    local descriptor = method_description(method)
    if descriptor.parameter_count ~= 0 or #descriptor.parameter_types ~= 0
        or not descriptor.parameter_types_available or not descriptor.static_metadata_available
        or descriptor.return_type == "unknown" or descriptor.return_type == "System.Void"
        or descriptor.is_static then
        add_missing(snapshot, "getter_signature", owner, selector)
        return nil, "getter_signature_unverified"
    end
    local called, value = call_member(method, "call", object)
    if not called then
        add_missing(snapshot, "getter_call", owner, selector)
        return nil, "getter_call_failed"
    end
    return value, value ~= nil and "observed" or "not_loaded"
end

local function inspect_character(snapshot, character, role, expected_character_type)
    local record = { role = role, state = "not_loaded", level_state = "not_observed" }
    if not character then return record end
    local ok, definition = call_member(character, "get_type_definition")
    if not ok or not definition then record.state = "type_unavailable"; return record end
    local class_verified, is_character = call_member(definition, "is_a", expected_character_type)
    if not expected_character_type or not class_verified or not is_character then
        record.state = "character_type_unverified"
        return record
    end
    record.character_type = type_name(definition)
    record.state = "observed"
    local human, human_state = read_getter(snapshot, character, "get_Human")
    if not human then record.level_state = human_state; return record end
    local context, context_state = read_getter(snapshot, human, "get_StatusContext")
    if not context then record.level_state = context_state; return record end
    local valid, context_type = call_member(context, "get_type_definition")
    if not valid or not context_type then record.level_state = "context_type_unavailable"; return record end
    record.status_context_type = type_name(context_type)
    describe_type(snapshot, context_type, { name = record.status_context_type, fields = { "_Level" } })
    local field_ok, field = call_member(context_type, "get_field", "_Level")
    if not field_ok or not field then record.level_state = "level_field_missing"; return record end
    local static_ok, is_static = call_member(field, "is_static")
    if not static_ok or is_static then record.level_state = "level_field_unverified"; return record end
    local read_ok, level = call_member(field, "get_data", context)
    if read_ok and type(level) == "number" and level == level and level >= 1
        and level <= 1000000 and level % 1 == 0 then
        record.level = level
        record.level_state = "observed"
    else record.level_state = "level_read_unverified" end
    return record
end

local function features()
    local result = {}
    for _, feature in ipairs(FEATURES) do
        result[#result + 1] = {
            key = feature.key, label = feature.label, status = "not_implemented",
            enabled = false, reason = feature.reason,
        }
    end
    return result
end

function Host.new(runtime)
    runtime = runtime or { sdk = sdk, reframework = reframework, json = json }
    local self = setmetatable({ runtime = runtime, revision = 0 }, Host)
    self.session_token = string.format("%d-%d", os.time(), math.floor(os.clock() * 1000000))
    self.snapshot = {
        schema_version = 1, stage = "diagnostic_source", state = "not_captured",
        gameplay_mutations_enabled = false, runtime_gameplay_validated = false,
        framework = {}, features = features(), types = {}, missing = {},
    }
    return self
end

function Host:refresh()
    self.revision = self.revision + 1
    local snapshot = {
        schema_version = 1,
        stage = "diagnostic_source",
        capture_token = self.session_token .. ":" .. self.revision,
        state = "host_unavailable",
        lua_version = _VERSION,
        gameplay_mutations_enabled = false,
        runtime_gameplay_validated = false,
        framework = {}, features = features(), types = {}, missing = {},
        player = { role = "arisen", state = "not_observed" },
        main_pawn = { role = "main_pawn", state = "not_observed", progression = "unchanged" },
        game_build = { state = "not_observed", reason = "No verified game-build getter implemented." },
        gold = { state = "not_read", reason = "No verified gold getter implemented." },
        experience = { state = "not_read", reason = "No verified player-only XP getter implemented." },
        unresolved = {
            "Player-only XP path preserving main-pawn XP and vocation rank",
            "Enemy death event and stable per-spawn identity, excluding corpses, pawns and NPCs",
            "Gold read/credit/debit and atomic purchase with native level/stat calculation and persistence",
            "Guild interaction and verified Vernworth shop identities",
            "Complete DS3 base and DLC catalogs, locally converted animation/model/effect assets",
            "All-vocation player-only equipment and spell behavior",
        },
    }
    self.snapshot = snapshot
    local game_ok, game_name = call_member(self.runtime.reframework, "get_game_name")
    if not game_ok or type(game_name) ~= "string" then
        add_missing(snapshot, "framework_api", "reframework", "get_game_name")
        return snapshot
    end
    snapshot.framework.game_name = game_name
    for _, pair in ipairs({ { "get_version_string", "api_version" }, { "get_tag", "build_tag" }, { "get_commit_hash", "build_commit" } }) do
        local ok, value = call_member(self.runtime.reframework, pair[1])
        if ok and type(value) == "string" then snapshot.framework[pair[2]] = value end
    end
    if game_name ~= "dd2" then snapshot.state = "unsupported_game"; return snapshot end
    local sdk_ready = true
    for _, name in ipairs({ "find_type_definition", "get_managed_singleton" }) do
        if not has_function(self.runtime.sdk, name) then
            sdk_ready = false
            add_missing(snapshot, "sdk_api", "sdk", name)
        end
    end
    if not sdk_ready then return snapshot end
    snapshot.framework.tdb_version_state = "not_observed"
    if has_function(self.runtime.sdk, "get_tdb_version") then
        local ok, value = call_function(self.runtime.sdk, "get_tdb_version")
        if ok and type(value) == "number" and value % 1 == 0 and value > 0 then
            snapshot.framework.tdb_version = value
            snapshot.framework.tdb_version_state = "observed"
        end
    else
        add_missing(snapshot, "sdk_api", "sdk", "get_tdb_version")
    end
    local definitions = {}
    for _, spec in ipairs(TYPE_SPECS) do
        local ok, definition = call_function(self.runtime.sdk, "find_type_definition", spec.name)
        definitions[spec.name] = ok and definition or nil
        describe_type(snapshot, definitions[spec.name], spec)
    end
    local cm_ok, character_manager = call_function(self.runtime.sdk, "get_managed_singleton", "app.CharacterManager")
    local pm_ok, pawn_manager = call_function(self.runtime.sdk, "get_managed_singleton", "app.PawnManager")
    if not cm_ok then character_manager = nil end
    if not pm_ok then pawn_manager = nil end
    if not character_manager then add_missing(snapshot, "singleton", "app.CharacterManager") end
    if not pawn_manager then add_missing(snapshot, "singleton", "app.PawnManager") end
    local player, player_state = read_getter(snapshot, character_manager, "get_ManualPlayer")
    local pawn_data, pawn_state = read_getter(snapshot, pawn_manager, "get_MainPawn")
    local pawn
    if pawn_data then
        local ok, pawn_type = call_member(pawn_data, "get_type_definition")
        if ok and pawn_type then describe_type(snapshot, pawn_type, { name = type_name(pawn_type), methods = { "get_CachedCharacter" } }) end
        pawn, pawn_state = read_getter(snapshot, pawn_data, "get_CachedCharacter")
    end
    snapshot.player = inspect_character(snapshot, player, "arisen", definitions["app.Character"])
    snapshot.main_pawn = inspect_character(snapshot, pawn, "main_pawn", definitions["app.Character"])
    snapshot.main_pawn.progression = "unchanged"
    snapshot.player.manager_getter_state = player_state
    snapshot.main_pawn.manager_getter_state = pawn_state
    if player and pawn then
        local player_ok, player_address = call_member(player, "get_address")
        local pawn_ok, pawn_address = call_member(pawn, "get_address")
        if player_ok and pawn_ok and type(player_address) == "number" and type(pawn_address) == "number"
            and player_address ~= 0 and pawn_address ~= 0 then
            snapshot.player.distinct_from_main_pawn = player_address ~= pawn_address
        end
    end
    -- Presence is diagnostic evidence; it never opens a mutation capability.
    if snapshot.player.state ~= "observed" then snapshot.state = "waiting_for_loaded_save"
    elseif snapshot.player.distinct_from_main_pawn == false then snapshot.state = "identity_conflict"
    elseif snapshot.player.distinct_from_main_pawn ~= true then snapshot.state = "pawn_identity_unverified"
    else snapshot.state = "read_only_identity_observed" end
    return snapshot
end

function Host:export_diagnostics()
    if not self.snapshot.capture_token then return false, "capture_required" end
    -- REFramework JSON paths are relative to reframework/data; its implementation
    -- creates parents. Never pass reframework/data again or dump managed objects.
    local ok, result = call_function(self.runtime.json, "dump_file", Host.DIAGNOSTIC_PATH, self.snapshot, 2)
    if not ok or result ~= true then return false, "diagnostic_write_failed" end
    local loaded, saved = call_function(self.runtime.json, "load_file", Host.DIAGNOSTIC_PATH)
    if not loaded or type(saved) ~= "table" or saved.capture_token ~= self.snapshot.capture_token then
        return false, "diagnostic_readback_failed"
    end
    return true, "diagnostic_exported"
end

-- This scope is intentionally much narrower than a gameplay validation suite.
function Host:smoke_check()
    local snapshot = self.snapshot
    return {
        scope = "read_only_host_diagnostic",
        state = snapshot.state,
        player_observed = snapshot.player and snapshot.player.state == "observed" or false,
        pawn_observed = snapshot.main_pawn and snapshot.main_pawn.state == "observed" or false,
        gameplay_validated = false,
        gameplay_mutations_enabled = false,
    }
end

return Host
