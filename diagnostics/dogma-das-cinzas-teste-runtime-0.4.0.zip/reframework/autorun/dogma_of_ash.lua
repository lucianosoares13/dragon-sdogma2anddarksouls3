-- SPDX-License-Identifier: MIT
-- Experimental diagnostic source, not a completed gameplay conversion.
local loaded, Host = pcall(require, "dogma_of_ash.host")
local host = loaded and type(Host) == "table" and Host.new() or nil
local captured = false
local export_message = "Diagnóstico ainda não exportado."

local STATES = {
    not_captured = "Aguardando captura.",
    host_unavailable = "API do REFramework indisponível.",
    unsupported_game = "Este diagnóstico requer Dragon's Dogma 2.",
    waiting_for_loaded_save = "Carregue um save e capture o diagnóstico novamente.",
    identity_conflict = "Nascen e peão não puderam ser distinguidos com segurança.",
    pawn_identity_unverified = "Nascen observado; falta confirmar a identidade do peão principal.",
    read_only_identity_observed = "Nascen e peão principal observados em leitura; jogabilidade ainda não validada.",
}

local function capture()
    if not host then return end
    host:refresh()
    captured = true
    export_message = "Diagnóstico atualizado; use Exportar diagnóstico para salvar esta captura."
end

-- A single frame callback avoids accessing game objects while the script loads.
-- No polling, sdk.hook, XP interception, currency writes or save edits occur.
if host and re and type(re.on_frame) == "function" then
    re.on_frame(function()
        if not captured then capture() end
    end)
end

if re and type(re.on_draw_ui) == "function" then
    re.on_draw_ui(function()
        if not imgui.tree_node("Dogma das Cinzas — diagnóstico experimental") then return end
        imgui.text("Fonte experimental — integração não validada")
        if not host then
            imgui.text("Não foi possível carregar dogma_of_ash.host. Reinstale os arquivos de diagnóstico.")
            imgui.tree_pop()
            return
        end
        if not captured then capture() end
        imgui.text(STATES[host.snapshot.state] or "Estado de diagnóstico desconhecido.")
        imgui.text("As alterações de jogabilidade estão indisponíveis nesta versão.")
        for _, feature in ipairs(host.snapshot.features) do
            imgui.text(feature.label .. ": não implementado; desativado.")
            if imgui.tree_node("Pendência##" .. feature.key) then
                imgui.text(feature.reason)
                imgui.tree_pop()
            end
        end
        if imgui.button("Capturar diagnóstico") then capture() end
        if imgui.button("Exportar diagnóstico") then
            local ok, code = host:export_diagnostics()
            export_message = ok and "Salvo em reframework/data/dogma_of_ash/diagnostics.json."
                or "Exportação falhou: " .. code .. "."
        end
        imgui.text(export_message)
        imgui.text("O JSON contém tipos, assinaturas e presença dos atores; não contém saves, nomes de jogador ou endereços de memória.")
        imgui.tree_pop()
    end)
end
