﻿#Requires -Version 5.1
<#
.SYNOPSIS
Le os dados da instalacao e grava diagnostico-instalacao.json junto ao pacote.
.DESCRIPTION
Nao instala loader, inicia jogos, le saves ou altera arquivos dos jogos.
Nao inclui caminhos absolutos, SteamIDs, certificados ou credenciais no JSON.
.EXAMPLE
.\tools\collect-installation.ps1
.EXAMPLE
.\tools\collect-installation.ps1 -GamePath 'D:\Games\Dragons Dogma 2' -SourceGamePath 'D:\Games\DARK SOULS III'
#>
[CmdletBinding()]
param(
    [string]$GamePath,
    [string]$SourceGamePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$schema = 'dogma-of-ash-installation-probe/v2'
$issues = [Collections.Generic.List[string]]::new()

function Get-SteamLibraries {
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -eq $item) { continue }
        foreach ($property in @('SteamPath', 'InstallPath')) {
            $value = $item.PSObject.Properties[$property]
            if ($null -ne $value -and $value.Value) { [void]$roots.Add([string]$value.Value) }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { [void]$roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        [void]$libraries.Add([IO.Path]::GetFullPath($root))
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        try { $content = Get-Content -Raw -LiteralPath $vdf }
        catch { $issues.Add('steamLibraryListUnreadable'); continue }
        foreach ($match in [regex]::Matches($content, '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
            $candidate = $match.Groups['path'].Value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) { [void]$libraries.Add([IO.Path]::GetFullPath($candidate)) }
        }
    }
    foreach ($library in $libraries) { $library }
}

function Get-InstalledDepotIds([string]$Content) {
    $tokens = @([regex]::Matches($Content, '"(?<text>(?:\\.|[^"\\])*)"|(?<brace>[{}])'))
    for ($i = 0; $i -lt $tokens.Count - 1; $i++) {
        if ($tokens[$i].Groups['text'].Value -ne 'InstalledDepots' -or $tokens[$i + 1].Value -ne '{') { continue }
        $depth = 1
        for ($j = $i + 2; $j -lt $tokens.Count; $j++) {
            if ($tokens[$j].Value -eq '{') { $depth++; continue }
            if ($tokens[$j].Value -eq '}') { $depth--; if ($depth -eq 0) { return }; continue }
            if ($depth -eq 1 -and $j + 1 -lt $tokens.Count -and $tokens[$j + 1].Value -eq '{' -and $tokens[$j].Groups['text'].Value -match '^\d+$') { $tokens[$j].Groups['text'].Value }
        }
        return
    }
}

function Find-SteamInstall([string]$AppId) {
    foreach ($library in @(Get-SteamLibraries)) {
        $manifest = Join-Path $library ('steamapps/appmanifest_{0}.acf' -f $AppId)
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        try {
            $content = Get-Content -Raw -LiteralPath $manifest
            $directory = [regex]::Match($content, '"installdir"\s+"(?<value>[^"\r\n]+)"')
            if (-not $directory.Success) { continue }
            $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
            $root = [IO.Path]::GetFullPath((Join-Path $common $directory.Groups['value'].Value))
            if (-not $root.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { continue }
            if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
            $name = [regex]::Match($content, '"name"\s+"(?<value>[^"\r\n]+)"').Groups['value'].Value
            if ($name -match '(?i)(?:[a-z]:[\\/]|^/|^\\\\)') { $name = $null }
            [pscustomobject]@{ root = $root; appId = $AppId; manifestName = $name; installedDepotIds = @(Get-InstalledDepotIds $content) }
        } catch { $issues.Add('steamManifestUnreadable-' + $AppId) }
    }
}

function Resolve-Installation([string]$Override, [string]$AppId) {
    if ($Override) {
        try {
            if (-not (Test-Path -LiteralPath $Override -PathType Container)) { throw 'invalid' }
            [pscustomobject]@{ root = (Resolve-Path -LiteralPath $Override).ProviderPath; discovery = 'explicitPath'; status = 'directoryFound'; steam = $null }
        } catch {
            $issues.Add('explicitGameDirectoryUnavailable-' + $AppId)
            [pscustomobject]@{ root = $null; discovery = 'explicitPath'; status = 'unavailable'; steam = $null }
        }
        return
    }
    $found = @(Find-SteamInstall $AppId | Sort-Object root -Unique)
    if ($found.Count -eq 1) { [pscustomobject]@{ root = $found[0].root; discovery = 'steam'; status = 'directoryFound'; steam = $found[0] } }
    else {
        $status = if ($found.Count -gt 1) { 'multipleInstallationsRequireOverride' } else { 'notFound' }
        $issues.Add('steamInstall-' + $AppId + '-' + $status)
        [pscustomobject]@{ root = $null; discovery = 'steam'; status = $status; steam = $null }
    }
}

function Get-FileMetadata([string]$Path) {
    $result = [ordered]@{ fileName = [IO.Path]::GetFileName($Path); status = 'read'; fileVersion = $null; productVersion = $null; sha256 = $null; authenticode = [ordered]@{ available = $false; status = 'unavailable' } }
    try {
        $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($Path)
        $result.fileVersion = $version.FileVersion
        $result.productVersion = $version.ProductVersion
    } catch { $result.status = 'partial'; $issues.Add('fileVersionUnreadable-' + $result.fileName) }
    try { $result.sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }
    catch { $result.status = 'partial'; $issues.Add('fileHashUnreadable-' + $result.fileName) }
    if (Get-Command Get-AuthenticodeSignature -ErrorAction SilentlyContinue) {
        try {
            $signature = Get-AuthenticodeSignature -LiteralPath $Path
            $result.authenticode.available = $true
            $result.authenticode.status = [string]$signature.Status
        } catch { $issues.Add('signatureStatusUnavailable-' + $result.fileName) }
    }
    $result
}

if ($env:OS -ne 'Windows_NT') { throw 'Execute este coletor no Windows. Ele nao instala loaders nem altera os jogos.' }

$hostInstall = Resolve-Installation $GamePath '2054970'
$sourceInstall = Resolve-Installation $SourceGamePath '374320'
$hostMetadata = @()
$rootExeNames = @()
$loaderMetadata = $null
if ($hostInstall.root) {
    try {
        foreach ($name in @('DD2.exe', 'DD2DA.exe')) {
            $path = Join-Path $hostInstall.root $name
            if (Test-Path -LiteralPath $path -PathType Leaf) { $hostMetadata += Get-FileMetadata $path }
        }
        if ($hostMetadata.Count -eq 0) {
            $rootExeNames = @(Get-ChildItem -LiteralPath $hostInstall.root -File -Filter '*.exe' | Sort-Object Name | Select-Object -ExpandProperty Name)
            $issues.Add('recognizedHostExecutableNotFound')
        }
        $loaderPath = Join-Path $hostInstall.root 'dinput8.dll'
        if (Test-Path -LiteralPath $loaderPath -PathType Leaf) { $loaderMetadata = Get-FileMetadata $loaderPath }
    } catch { $issues.Add('hostDirectoryInspectionIncomplete') }
}

$sourceMetadata = $null
if ($sourceInstall.root) {
    foreach ($relative in @('DarkSoulsIII.exe', 'Game/DarkSoulsIII.exe')) {
        $path = Join-Path $sourceInstall.root $relative
        if (Test-Path -LiteralPath $path -PathType Leaf) { $sourceMetadata = Get-FileMetadata $path; break }
    }
    if (-not $sourceMetadata) { $issues.Add('sourceExecutableNotFound') }
}

$hostSteam = if ($hostInstall.steam) { [ordered]@{ manifestName = $hostInstall.steam.manifestName; installedDepotIds = @($hostInstall.steam.installedDepotIds) } } else { $null }
$sourceSteam = if ($sourceInstall.steam) { [ordered]@{ manifestName = $sourceInstall.steam.manifestName; installedDepotIds = @($sourceInstall.steam.installedDepotIds) } } else { $null }
$report = [ordered]@{
    schema = $schema
    collectedAtUtc = [DateTime]::UtcNow.ToString('o')
    status = $(if ($issues.Count -eq 0) { 'collected' } else { 'partial' })
    target = "Dragon's Dogma 2: Dark Arisen Expansion"
    powerShellVersion = $PSVersionTable.PSVersion.ToString()
    host = [ordered]@{ appId = '2054970'; discovery = $hostInstall.discovery; directoryStatus = $hostInstall.status; recognizedExecutableFound = ($hostMetadata.Count -gt 0); executables = @($hostMetadata); rootExeNames = @($rootExeNames); steam = $hostSteam; existingLoader = $loaderMetadata; loaderCompatibility = 'unknownForRequestedExpansion' }
    requestedExpansion = [ordered]@{ appId = '2593290'; verification = 'manualOrRuntimeCorrelationRequired'; absenceInManifestDoesNotProveAbsence = $true }
    source = [ordered]@{ appId = '374320'; discovery = $sourceInstall.discovery; directoryStatus = $sourceInstall.status; detected = [bool]$sourceMetadata; executable = $sourceMetadata; steam = $sourceSteam }
    operations = [ordered]@{ gameFilesChanged = $false; loaderInstalled = $false; gameStarted = $false; savesRead = $false; assetsImported = $false }
    issues = @($issues | Select-Object -Unique)
}

$output = Join-Path (Split-Path -Parent $PSScriptRoot) 'diagnostico-instalacao.json'
if (Test-Path -LiteralPath $output) {
    try { $previous = Get-Content -Raw -LiteralPath $output | ConvertFrom-Json }
    catch { throw 'Um arquivo diagnostico-instalacao.json nao reconhecido ja existe. Preserve-o antes de repetir a coleta.' }
    if ($previous.schema -ne $schema) { throw 'Um arquivo diagnostico-instalacao.json nao reconhecido ja existe. Preserve-o antes de repetir a coleta.' }
}
try { [IO.File]::WriteAllText($output, ($report | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false)) }
catch { throw 'Nao foi possivel gravar diagnostico-instalacao.json. Extraia o pacote em uma pasta em que voce possa escrever.' }
Write-Host 'Diagnostico salvo em diagnostico-instalacao.json, ao lado deste pacote.'
Write-Host 'Nenhum jogo foi iniciado ou alterado. Envie o JSON para verificar a instalacao e a compatibilidade da expansao.'
