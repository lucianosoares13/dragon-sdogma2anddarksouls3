# Verificar Dragon's Dogma 2: Dark Arisen Expansion

Este pacote consulta a instalação e cria um relatório para escolher as
ferramentas compatíveis. Não instala DLL, não inicia o jogo e não altera
os arquivos dos jogos ou os saves. Ainda não contém o mashup jogável.

1. Extraia completamente o ZIP recebido.
2. Dê dois cliques em **verificar-instalacao.cmd**.
3. Na pasta extraída, aparecerá **diagnostico-instalacao.json**.
   Envie esse arquivo nesta conversa.

O script procura Dragon's Dogma 2 e Dark Souls III nas bibliotecas Steam.
Ele registra versões, hashes de executáveis e a presença de um loader,
sem copiar arquivos dos jogos, caminhos absolutos ou dados da sua conta.
A presença do DLC precisa ser correlacionada com a versão e os arquivos
instalados; a ausência de um manifesto separado de DLC não significa que
você não o possui.

Se ocorrer um erro, envie o texto da mensagem. O script preserva a política
de execução do PowerShell. Para instalações fora do Steam, ele aceita
`-GamePath` e `-SourceGamePath`, conforme seus exemplos no próprio script.

O alvo confirmado é a expansão de **Dragon's Dogma 2**, Steam DLC 2593290
do jogo 2054970. Isso é diferente de **Dragon's Dogma: Dark Arisen**,
o primeiro jogo, Steam 367500.

O diagnóstico anterior 0.1.0 usava REFramework v1.5.9.1 para DD2. A
compatibilidade dessa build com Dark Arisen Expansion não está confirmada.
Esse pacote anterior fica suspenso até escolher e validar um loader para
a expansão. Nenhuma falta de configuração no catálogo do Melty muda o
jogo escolhido para o projeto.
