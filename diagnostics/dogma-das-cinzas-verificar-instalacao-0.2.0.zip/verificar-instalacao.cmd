@echo off
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -File "%~dp0tools\collect-installation.ps1"
set "dogma_probe_exit=%ERRORLEVEL%"
echo.
pause
exit /b %dogma_probe_exit%
