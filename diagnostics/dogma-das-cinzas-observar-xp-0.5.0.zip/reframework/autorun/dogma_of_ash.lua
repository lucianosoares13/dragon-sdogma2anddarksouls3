-- SPDX-License-Identifier: MIT
-- Experimental diagnostic source, not a completed gameplay conversion.
local loaded, Host = pcall(require, "dogma_of_ash.host")
local host = loaded and type(Host) == "table" and Host.new() or nil
local observe_loaded, Observe = pcall(require, "dogma_of_ash.observe")
local observer = host and observe_loaded and type(Observe) == "table"
    and type(Observe.new) == "function"
    and Observe.new({ sdk = sdk }, function() return host:actor_addresses() end) or nil
local observation_before
local observation_message = "Observação de XP ainda não iniciada."
local captured = false
local export_message = "Diagnóstico ainda não exportado."

local STATES = {
    not_captured = "Aguardando captura.",
    host_unavailable = "API do REFramework indisponível.",
    unsupported_game = "Este diagnóstico requer Dragon's Dogma 2.",
    waiting_for_loaded_save = "Carregue um save e capture o diagnóstico novamente.",
    identity_conflict = "Nascen e peão não puderam ser distinguidos com segurança.",
    pawn_identity_unverified = "Nascen observado; falta confirmar a identidade do peão principal.",
    read_only_identity_observed = "Nascen e peão principal observados em leitura; jogabilidade ainda não validada.",
}

local function actor_metrics(snapshot)
    local result = {}
    for _, role in ipairs({ "player", "main_pawn" }) do
        local actor = snapshot[role] or {}
        result[role] = {
            exp = actor.exp, exp_state = actor.exp_state,
            level = actor.level, level_state = actor.level_state, job = actor.job,
        }
    end
    return result
end

local function attach_observation()
    if not host or not observer then return end
    local observation = observer:snapshot()
    observation.before = observation_before
    if observation_before and not observer.active then
        observation.after = actor_metrics(host.snapshot)
    end
    host.snapshot.observation = observation
end

local function capture()
    if not host then return end
    host:refresh()
    captured = true
    attach_observation()
    export_message = "Diagnóstico atualizado; use Exportar diagnóstico para salvar esta captura."
end

local function start_observation()
    if not host or not observer then return end
    if observer.active then return end
    capture()
    local ok, reason = observer:start()
    if ok then
        observation_before = actor_metrics(host.snapshot)
        observation_message = "Observando. Feche o painel e derrote um inimigo com seu peão presente."
    elseif reason == "identity_unverified" then
        observation_message = "Carregue uma partida com seu peão principal e tente novamente."
    else
        observation_message = "Não foi possível iniciar a observação. Envie uma foto deste painel."
    end
    attach_observation()
end

local function stop_observation()
    if not host or not observer then return end
    observer:stop()
    capture()
    observation_message = "Observação encerrada. Use Exportar diagnóstico para salvar o relatório."
end

-- A single frame callback avoids accessing game objects while the script loads.
-- The optional XP hook is registered only after the user starts observation.
-- It never changes arguments/results. No polling or gameplay writes occur.
if host and re and type(re.on_frame) == "function" then
    re.on_frame(function()
        if not captured then capture() end
    end)
end

if re and type(re.on_draw_ui) == "function" then
    re.on_draw_ui(function()
        if not imgui.tree_node("Dogma das Cinzas — diagnóstico experimental") then return end
        imgui.text("Fonte experimental — integração não validada")
        if not host then
            imgui.text("Não foi possível carregar dogma_of_ash.host. Reinstale os arquivos de diagnóstico.")
            imgui.tree_pop()
            return
        end
        if not captured then capture() end
        imgui.text(STATES[host.snapshot.state] or "Estado de diagnóstico desconhecido.")
        imgui.text("As alterações de jogabilidade estão indisponíveis nesta versão.")
        if observer then
            if imgui.button("Iniciar observação de XP") then start_observation() end
            if imgui.button("Parar observação de XP") then stop_observation() end
            imgui.text(observation_message)
            imgui.text("Concessões registradas: " .. tostring(observer.event_count_total or 0))
        else
            imgui.text("Observação indisponível. Extraia e instale o pacote completo.")
        end
        if imgui.button("Capturar diagnóstico") then capture() end
        if imgui.button("Exportar diagnóstico") then
            if observer and observer.active then stop_observation() end
            attach_observation()
            local ok, code = host:export_diagnostics()
            export_message = ok and "Salvo em reframework/data/dogma_of_ash/diagnostics.json."
                or "Exportação falhou: " .. code .. "."
        end
        imgui.text(export_message)
        for _, feature in ipairs(host.snapshot.features) do
            imgui.text(feature.label .. ": não implementado; desativado.")
            if imgui.tree_node("Pendência##" .. feature.key) then
                imgui.text(feature.reason)
                imgui.tree_pop()
            end
        end
        imgui.text("O JSON contém tipos, assinaturas e presença dos atores; não contém saves, nomes de jogador ou endereços de memória.")
        imgui.tree_pop()
    end)
end
