-- Pure Lua rules only. This module neither reads nor modifies a game save.
-- A verified DD2 host adapter must supply native stat gains, suppress normal
-- player XP only when gold progression is operational, and leave pawns alone.
local M = {}

local REWARDS = {
    { amount = 50, weight = 50 },
    { amount = 200, weight = 40 },
    { amount = 500, weight = 30 },
    { amount = 1000, weight = 10 },
    { amount = 5000, weight = 1 },
}
local TOTAL_WEIGHT = 131
local issued_quotes = setmetatable({}, { __mode = "k" })

local function integer(value)
    return type(value) == "number" and math.type(value) == "integer"
end

local function finite_nonnegative(value)
    return type(value) == "number" and value == value
        and value >= 0 and value < math.huge
end

local function stable_id(value)
    return (type(value) == "string" and #value > 0)
        or (integer(value) and value >= 0)
end

local function copy(value)
    if type(value) ~= "table" then return value end
    local result = {}
    for key, item in pairs(value) do result[key] = copy(item) end
    return result
end

local function equal(left, right)
    if type(left) ~= type(right) then return false end
    if type(left) ~= "table" then return left == right end
    for key, value in pairs(left) do
        if not equal(value, right[key]) then return false end
    end
    for key in pairs(right) do
        if left[key] == nil then return false end
    end
    return true
end

-- Returns a copy: modifying it cannot change the lottery's internal weights.
function M.reward_distribution()
    return copy(REWARDS), TOTAL_WEIGHT
end

-- The RNG is injected for deterministic tests; it must return an integer in
-- the inclusive range [1, 131]. There is exactly one reward per valid draw.
function M.sample_gold(rng)
    if type(rng) ~= "function" then return nil, "invalid_rng" end
    local ok, slot = pcall(rng, 1, TOTAL_WEIGHT)
    if not ok then return nil, "rng_failed" end
    if not integer(slot) or slot < 1 or slot > TOTAL_WEIGHT then
        return nil, "invalid_rng_result"
    end
    local upper = 0
    for _, reward in ipairs(REWARDS) do
        upper = upper + reward.weight
        if slot <= upper then return reward.amount end
    end
    return nil, "invalid_distribution"
end

-- Session-only deduplication. The caller must pass an actual, new enemy death
-- event, never a scan/poll of corpses. The stable key must identify the same
-- spawn across corpse reloads; a transient object address is not sufficient.
-- Claiming allocates a reward; it does not credit game gold. A future host must
-- coordinate reward delivery and deduplication atomically, including failures.
function M.new_death_tracker()
    local seen = {}
    local tracker = {}
    function tracker:claim_new_death(event, rng)
        if type(event) ~= "table" or event.kind ~= "new_death" then
            return nil, "new_death_event_required"
        end
        local key = event.stable_key
        if not stable_id(key) then return nil, "stable_enemy_key_required" end
        if seen[key] then return nil, "duplicate_death" end
        local amount, err = M.sample_gold(rng)
        if not amount then return nil, err end
        seen[key] = true
        return amount
    end
    return tracker
end

-- Policy, not a hook. Player gold progression replaces normal level XP;
-- the main pawn and other pawn progression continue through the native game.
function M.progression_policy(target)
    if target == "player" then return "gold" end
    if target == "main_pawn" or target == "pawn" then return "native" end
    return nil, "unknown_target"
end

local function price_for_level(level, tuning)
    -- Provisional mod balancing, configurable; these are not DS3 soul costs.
    tuning = tuning or {}
    if type(tuning) ~= "table" then return nil, "invalid_tuning" end
    local initial = tuning.initial_price
    local increment = tuning.per_level
    if initial == nil then initial = 1000 end
    if increment == nil then increment = 250 end
    if not integer(initial) or initial < 1
        or not integer(increment) or increment < 0 then
        return nil, "invalid_tuning"
    end
    if increment > 0 and level - 1 > (math.maxinteger - initial) // increment then
        return nil, "price_overflow"
    end
    return initial + increment * (level - 1),
        { initial_price = initial, per_level = increment }
end

local function snapshot(state)
    if type(state) ~= "table" then return nil, "invalid_state" end
    if state.target ~= "player" then return nil, "player_only" end
    if not stable_id(state.actor_id) or not stable_id(state.vocation_id)
        or not stable_id(state.revision) then
        return nil, "missing_state_identity"
    end
    if not integer(state.gold) or state.gold < 0 then return nil, "invalid_gold" end
    if not integer(state.level) or state.level < 1
        or not integer(state.level_cap) or state.level_cap < 1 then
        return nil, "invalid_level"
    end
    if state.level > state.level_cap then return nil, "level_cap_exceeded" end
    if not integer(state.vocation_rank) or state.vocation_rank < 0
        or not integer(state.vocation_rank_cap) or state.vocation_rank_cap < 0 then
        return nil, "invalid_rank"
    end
    if state.vocation_rank > state.vocation_rank_cap then
        return nil, "rank_cap_exceeded"
    end
    if type(state.attributes) ~= "table" or type(state.attribute_caps) ~= "table" then
        return nil, "native_attributes_required"
    end
    local attributes, caps, count = {}, {}, 0
    for key, value in pairs(state.attributes) do
        if type(key) ~= "string" or #key == 0 or not finite_nonnegative(value)
            or not finite_nonnegative(state.attribute_caps[key]) then
            return nil, "invalid_attribute"
        end
        if value > state.attribute_caps[key] then return nil, "attribute_cap_exceeded" end
        attributes[key], caps[key] = value, state.attribute_caps[key]
        count = count + 1
    end
    if count == 0 then return nil, "native_attributes_required" end
    for key in pairs(state.attribute_caps) do
        if attributes[key] == nil then return nil, "invalid_attribute_caps" end
    end
    return {
        target = state.target, actor_id = state.actor_id, gold = state.gold,
        level = state.level, level_cap = state.level_cap,
        vocation_id = state.vocation_id, vocation_rank = state.vocation_rank,
        vocation_rank_cap = state.vocation_rank_cap, revision = state.revision,
        attributes = attributes, attribute_caps = caps,
    }
end

local function validate_native_quote(before, native_quote)
    if type(native_quote) ~= "table" then return nil, "native_quote_required" end
    if native_quote.next_level ~= before.level + 1 then
        return nil, "invalid_native_level"
    end
    if native_quote.next_vocation_rank ~= before.vocation_rank then
        return nil, "rank_change_forbidden"
    end
    if type(native_quote.next_attributes) ~= "table" then
        return nil, "native_attributes_required"
    end
    local after, gained = {}, false
    for key, value in pairs(before.attributes) do
        local next_value = native_quote.next_attributes[key]
        if not finite_nonnegative(next_value) or next_value < value then
            return nil, "invalid_native_attribute"
        end
        if next_value > before.attribute_caps[key] then
            return nil, "attribute_cap_exceeded"
        end
        gained = gained or next_value > value
        after[key] = next_value
    end
    for key in pairs(native_quote.next_attributes) do
        if before.attributes[key] == nil then return nil, "invalid_native_attribute" end
    end
    if not gained then return nil, "no_stat_gain" end
    return after
end

-- native_quote must come from a verified, read-only native DD2 calculation.
-- This module does not invent per-vocation gains or call unverified game APIs.
-- Quotes are valid only in this module instance/session and are tamper checked.
function M.quote_level_up(state, tuning, native_quote)
    local before, err = snapshot(state)
    if not before then return nil, err end
    if before.level >= before.level_cap then return nil, "level_cap_reached" end
    local cost, normalized = price_for_level(before.level, tuning)
    if not cost then return nil, normalized end
    if before.gold < cost then return nil, "insufficient_gold" end
    local next_attributes, native_error = validate_native_quote(before, native_quote)
    if not next_attributes then return nil, native_error end
    local quote = {
        expected = before, cost = cost, tuning = normalized,
        next_level = before.level + 1,
        next_vocation_rank = before.vocation_rank,
        next_attributes = next_attributes,
    }
    issued_quotes[quote] = copy(quote)
    return quote
end

-- Produces instructions, without mutating either input or a game save.
function M.plan_level_up(quote, current_state, tuning)
    if type(quote) ~= "table" or not issued_quotes[quote] then
        return nil, "invalid_quote"
    end
    local canonical = issued_quotes[quote]
    if not equal(quote, canonical) then return nil, "modified_quote" end
    local current, err = snapshot(current_state)
    if not current then return nil, err end
    if not equal(current, canonical.expected) then return nil, "stale_quote" end
    local cost, normalized = price_for_level(current.level, tuning)
    if not cost then return nil, normalized end
    if not equal(normalized, canonical.tuning) or cost ~= canonical.cost then
        return nil, "stale_tuning"
    end
    if current.gold < cost then return nil, "insufficient_gold" end
    if current.level >= current.level_cap then return nil, "level_cap_reached" end
    local next_attributes, native_error = validate_native_quote(current, canonical)
    if not next_attributes then return nil, native_error end
    local after = copy(current)
    after.gold = current.gold - cost
    after.level = canonical.next_level
    after.attributes = next_attributes
    -- revision changes must be assigned by the native host during its commit.
    return { cost = cost, expected = copy(current), after = after }
end

local function adapter_valid(adapter, need_quote)
    if type(adapter) ~= "table" or type(adapter.capture_state) ~= "function" then
        return nil, "capture_adapter_required"
    end
    if need_quote and type(adapter.quote_native_level_up) ~= "function" then
        return nil, "native_quote_adapter_required"
    end
    return true
end

local function call_adapter(method, ...)
    local ok, result, err = pcall(method, ...)
    if not ok then return nil, "adapter_failed" end
    if result == nil or result == false then return nil, err or "adapter_rejected" end
    return result, err
end

-- Adapter methods are plain functions (no implicit self). Capture/quote must
-- be read-only. Only a native adapter can decide the real attribute gains.
function M.capture_quote(adapter, tuning)
    local valid, err = adapter_valid(adapter, true)
    if not valid then return nil, err end
    local state, capture_error = call_adapter(adapter.capture_state)
    if not state then return nil, capture_error end
    local before, state_error = snapshot(state)
    if not before then return nil, state_error end
    local native_quote, native_error = call_adapter(adapter.quote_native_level_up, copy(before))
    if not native_quote then return nil, native_error end
    return M.quote_level_up(before, tuning, native_quote)
end

-- The host MUST implement atomic_purchase(plan, check_current_state): acquire
-- its native transaction/guard, recapture state and call check_current_state
-- within that same guard, then commit gold + level + native stats together.
-- Return exactly true only after a successful atomic commit; otherwise nil,
-- a failure code, and leave all game state unchanged. Recheck prevents the
-- race between capture and commit. This coordinator cannot manufacture an
-- atomic game transaction, and deliberately has no write/refund fallback.
function M.purchase_level_up(adapter, quote, tuning)
    local valid, err = adapter_valid(adapter, false)
    if not valid then return nil, err end
    if type(adapter.atomic_purchase) ~= "function" then
        return nil, "atomic_purchase_adapter_required"
    end
    local state, capture_error = call_adapter(adapter.capture_state)
    if not state then return nil, capture_error end
    local plan, plan_error = M.plan_level_up(quote, state, tuning)
    if not plan then return nil, plan_error end
    local checked = false
    local function check_current_state(current_state)
        local checked_plan, check_error = M.plan_level_up(quote, current_state, tuning)
        if not checked_plan then return nil, check_error end
        checked = true
        return checked_plan
    end
    local committed, commit_error = call_adapter(adapter.atomic_purchase, copy(plan), check_current_state)
    if not committed then return nil, commit_error end
    if committed ~= true or not checked then return nil, "atomic_contract_violation" end
    -- A quote is single-use after a successful atomic purchase.
    issued_quotes[quote] = nil
    return true
end

return M
