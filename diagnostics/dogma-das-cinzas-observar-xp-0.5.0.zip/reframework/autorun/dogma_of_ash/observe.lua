-- SPDX-License-Identifier: MIT
-- Passive recipient observation: no native argument, result, XP or DCP writes.
-- Static hook argument positions are verified against the installed loader:
-- https://github.com/praydog/REFramework/blob/0a07faae46a6fc1c51cd1699a0cf99a3f9c2679f/src/HookManager.cpp#L278-L285
-- https://github.com/praydog/REFramework/blob/0a07faae46a6fc1c51cd1699a0cf99a3f9c2679f/src/mods/ScriptRunner.cpp#L795-L813
-- Native vector[0] is thread context; static parameters begin at vector[1].
-- Lua args therefore hold status at [3], candidate XP at [5], DCP at [6].
-- The meaning of these two Int32 parameters still needs runtime validation.
local Observe = {}
Observe.__index = Observe
Observe.SOURCE = "app.ExpDispenser.addExpAndJobPoint"
Observe.SELECTOR = "addExpAndJobPoint(app.CharacterID, app.HumanStatusContext, app.JobContext, System.Int32, System.Int32, System.Boolean, app.DragonHermitContext)"
Observe.MAX_EVENTS = 64

local PARAMETER_TYPES = {
    "app.CharacterID", "app.HumanStatusContext", "app.JobContext",
    "System.Int32", "System.Int32", "System.Boolean", "app.DragonHermitContext",
}

-- SDK hooks have no public unhook in this loader. Reuse the same registration
-- if an observer is stopped and restarted, or replaced within this Lua module.
local registrations = setmetatable({}, { __mode = "k" })

local function member(object, name, ...)
    local parameters = table.pack(...)
    return pcall(function()
        local fn = object and object[name]
        if type(fn) ~= "function" then error("member_unavailable") end
        return fn(object, table.unpack(parameters, 1, parameters.n))
    end)
end

local function named_type(definition, expected)
    local ok, name = member(definition, "get_full_name")
    return ok and name == expected
end

local function validated_method(runtime_sdk)
    if not runtime_sdk or type(runtime_sdk.find_type_definition) ~= "function"
        or type(runtime_sdk.hook) ~= "function" or type(runtime_sdk.to_int64) ~= "function" then
        return nil, "sdk_unavailable"
    end
    local found, definition = pcall(runtime_sdk.find_type_definition, "app.ExpDispenser")
    if not found or not named_type(definition, "app.ExpDispenser") then
        return nil, "type_unverified"
    end
    local resolved, method = member(definition, "get_method", Observe.SELECTOR)
    if not resolved or not method then return nil, "method_unavailable" end
    local static_ok, is_static = member(method, "is_static")
    local count_ok, count = member(method, "get_num_params")
    local name_ok, name = member(method, "get_name")
    local owner_ok, owner = member(method, "get_declaring_type")
    local return_ok, return_type = member(method, "get_return_type")
    if not static_ok or is_static ~= true or not count_ok or count ~= #PARAMETER_TYPES
        or not name_ok or name ~= "addExpAndJobPoint" or not owner_ok
        or not named_type(owner, "app.ExpDispenser") or not return_ok
        or not named_type(return_type, "System.Void") then
        return nil, "signature_unverified"
    end
    local types_ok, types = member(method, "get_param_types")
    if not types_ok or types == nil then return nil, "signature_unverified" end
    local count_seen = 0
    local iterable = pcall(function()
        for index, parameter in ipairs(types) do
            if index > #PARAMETER_TYPES or not named_type(parameter, PARAMETER_TYPES[index]) then
                error("parameter_type_mismatch")
            end
            count_seen = count_seen + 1
        end
    end)
    if not iterable or count_seen ~= #PARAMETER_TYPES then
        return nil, "signature_unverified"
    end
    -- Names help distinguish the two Int32 values without invoking the method.
    local names_ok, names = member(method, "get_param_names")
    local parameter_names = {}
    if names_ok and names ~= nil then
        local copied = pcall(function()
            for index, parameter_name in ipairs(names) do
                if index > #PARAMETER_TYPES or type(parameter_name) ~= "string"
                    or #parameter_name > 128
                    or not parameter_name:match("^[A-Za-z_][A-Za-z0-9_]*$") then
                    error("parameter_name_unverified")
                end
                parameter_names[index] = parameter_name
            end
        end)
        if not copied then parameter_names = {} end
    end
    return method, nil, parameter_names
end

local function address(value)
    return type(value) == "number" and value == value and value > 0
        and value <= math.maxinteger and value % 1 == 0
end

local function identities(provider)
    if type(provider) ~= "function" then return nil end
    local ok, arisen, main_pawn = pcall(provider)
    if ok and address(arisen) and address(main_pawn) and arisen ~= main_pawn then
        return arisen, main_pawn
    end
    return nil
end

local function pointer_value(runtime_sdk, value)
    if value == nil then return nil end
    local ok, integer = pcall(runtime_sdk.to_int64, value)
    if ok and type(integer) == "number" and math.type(integer) == "integer" then
        return integer
    end
    return nil
end

local function int32(runtime_sdk, value)
    -- Hook values are void* bit patterns. A null representation is Int32 zero.
    if value == nil then return 0 end
    local integer = pointer_value(runtime_sdk, value)
    if integer == nil then return nil end
    local low = integer & 0xffffffff
    return low >= 0x80000000 and low - 0x100000000 or low
end

function Observe.new(runtime, address_provider)
    return setmetatable({
        sdk = runtime and runtime.sdk,
        address_provider = address_provider,
        active = false, hook_installed = false, state = "not_started",
        events = {}, timecounter = 0, event_count_total = 0,
        ignored_count = 0, error_count = 0, parameter_names = {},
    }, Observe)
end

function Observe:_record(args)
    if not self.active then return end
    self.timecounter = self.timecounter + 1
    local arisen, main_pawn = identities(self.address_provider)
    if not arisen then self.ignored_count = self.ignored_count + 1; return end
    -- Only compare the address against already validated live contexts.
    -- Never turn an unknown argument pointer into a managed object.
    local context = pointer_value(self.sdk, args[3])
    local role = context == arisen and "arisen" or context == main_pawn and "main_pawn" or nil
    if not role then self.ignored_count = self.ignored_count + 1; return end
    local xp, jobpoints = int32(self.sdk, args[5]), int32(self.sdk, args[6])
    if xp == nil or jobpoints == nil then
        self.error_count = self.error_count + 1
        return
    end
    self.event_count_total = self.event_count_total + 1
    self.events[#self.events + 1] = {
        role = role, source = Observe.SOURCE,
        xp = xp, jobpoints = jobpoints, timecounter = self.timecounter,
    }
    if #self.events > Observe.MAX_EVENTS then table.remove(self.events, 1) end
end

function Observe:start()
    if self.active then return true end
    if not identities(self.address_provider) then
        self.state = "identity_unverified"
        return false, self.state
    end
    local method, reason, parameter_names = validated_method(self.sdk)
    if not method then self.state = reason; return false, reason end
    local registration = registrations[self.sdk]
    if registration and registration.owner ~= self and registration.owner.active then
        self.state = "observer_already_active"
        return false, self.state
    end
    if not registration then
        registration = { owner = self }
        local installed, hook_result = pcall(self.sdk.hook, method, function(args)
            local owner = registration.owner
            if owner and owner.active then
                local ok = pcall(owner._record, owner, args)
                if not ok then
                    owner.error_count = owner.error_count + 1
                    owner.active = false
                    owner.state = "observer_error"
                end
            end
            -- nil retains CALL_ORIGINAL. There is no post hook or result edit.
            return nil
        end, nil)
        -- The pinned SDK binding returns void (Lua nil) on success.
        if not installed or hook_result == false then
            self.state = "hook_install_failed"
            return false, self.state
        end
        registrations[self.sdk] = registration
    end
    registration.owner = self
    self.parameter_names = parameter_names
    self.events = {}
    self.timecounter, self.event_count_total = 0, 0
    self.ignored_count, self.error_count = 0, 0
    self.hook_installed = true
    self.active = true
    self.state = "observing"
    return true
end

function Observe:stop()
    self.active = false
    self.state = "stopped"
end

function Observe:snapshot()
    local events, parameter_names = {}, {}
    for index, event in ipairs(self.events) do
        events[index] = {
            role = event.role, source = event.source, xp = event.xp,
            jobpoints = event.jobpoints, timecounter = event.timecounter,
        }
    end
    for index, name in ipairs(self.parameter_names) do parameter_names[index] = name end
    return {
        state = self.state, active = self.active, hook_installed = self.hook_installed,
        source = Observe.SOURCE, selector = Observe.SELECTOR,
        argument_semantics = "pending_runtime_validation",
        gameplay_mutations_enabled = false, parameter_names = parameter_names,
        event_count_total = self.event_count_total, event_count_retained = #events,
        discarded_count = self.event_count_total - #events, ignored_count = self.ignored_count,
        error_count = self.error_count, timecounter = self.timecounter, events = events,
    }
end

return Observe
