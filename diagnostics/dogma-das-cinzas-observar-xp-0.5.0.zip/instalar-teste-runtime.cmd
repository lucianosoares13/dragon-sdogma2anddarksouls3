@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DOGMA_RUNTIME_SCRIPT=%~dp0tools\install-runtime-test.ps1"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $p=$env:DOGMA_RUNTIME_SCRIPT; if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne 'f79af1156d491c7daca21a8c5d113895484ec2e0914564dcefd7d48e7ed59f41') { throw 'O script foi alterado. Baixe e extraia o ZIP novamente.' }; Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop; Unblock-File -LiteralPath $p -ErrorAction Stop; & $p; exit 0 } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }"
set "DOGMA_RUNTIME_EXIT=%ERRORLEVEL%"
if not "%DOGMA_RUNTIME_EXIT%"=="0" goto failed
echo.
echo Instalacao concluida. Abra DD2 normalmente e siga o README.
goto finished
:failed
echo.
echo Nao foi possivel concluir. Envie uma foto do erro acima.
:finished
pause
exit /b %DOGMA_RUNTIME_EXIT%
