@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DOGMA_RUNTIME_SCRIPT=%~dp0tools\remove-runtime-test.ps1"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $p=$env:DOGMA_RUNTIME_SCRIPT; if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne '2a4cdd32dc9328a9cde8e6f37f1dd7b48a000823c1a9ab041fa144010a47bd0e') { throw 'O script foi alterado. Baixe e extraia o ZIP novamente.' }; Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop; Unblock-File -LiteralPath $p -ErrorAction Stop; & $p; exit 0 } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }"
set "DOGMA_RUNTIME_EXIT=%ERRORLEVEL%"
if not "%DOGMA_RUNTIME_EXIT%"=="0" goto failed
echo.
echo Verificacao de retirada concluida. Seus outros mods foram preservados.
goto finished
:failed
echo.
echo Nao foi possivel concluir. Envie uma foto do erro acima.
:finished
pause
exit /b %DOGMA_RUNTIME_EXIT%
