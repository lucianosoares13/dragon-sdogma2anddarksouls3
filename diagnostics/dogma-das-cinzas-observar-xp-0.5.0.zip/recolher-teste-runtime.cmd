@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DOGMA_RUNTIME_SCRIPT=%~dp0tools\collect-runtime-test.ps1"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $p=$env:DOGMA_RUNTIME_SCRIPT; if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne '1f740276addb882b3e70612aa3970fd3f78097952eba79199ac1152769a16dac') { throw 'O script foi alterado. Baixe e extraia o ZIP novamente.' }; Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop; Unblock-File -LiteralPath $p -ErrorAction Stop; & $p; exit 0 } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }"
set "DOGMA_RUNTIME_EXIT=%ERRORLEVEL%"
if not "%DOGMA_RUNTIME_EXIT%"=="0" goto failed
echo.
echo Envie diagnostico-runtime.json, nesta mesma pasta.
goto finished
:failed
echo.
echo Nao foi possivel concluir. Envie uma foto do erro acima.
:finished
pause
exit /b %DOGMA_RUNTIME_EXIT%
