# Observar o ganho de XP

O primeiro diagnóstico funcionou: o Nascen e o peão foram identificados como
personagens distintos. Este teste acompanha como o jogo distribui XP e pontos
de vocação. Ainda não substitui a evolução por ouro nem habilita o mashup.

1. Feche DD2 e extraia todos os arquivos do novo ZIP em uma nova pasta.
2. Execute **instalar-teste-runtime.cmd**. Ele atualiza os scripts próprios
   da versão 0.4.0 e preserva o loader e os outros mods.
3. Abra DD2, carregue uma partida com seu peão principal e aperte **Insert**.
4. Abra **Script Generated UI → Dogma das Cinzas — diagnóstico experimental**.
5. Clique em **Iniciar observação de XP**, feche o painel com **Insert** e
   derrote um inimigo com o peão presente.
6. Reabra o painel, clique em **Parar observação de XP** e em
   **Exportar diagnóstico**.
7. Na pasta extraída, execute **recolher-teste-runtime.cmd** e envie o
   arquivo **diagnostico-runtime.json** criado ali.

O teste observa as chamadas naturais do jogo; não muda os valores de XP,
pontos de vocação, ouro, atributos ou saves. O relatório reúne o XP antes e
depois da observação, o personagem que recebeu cada concessão e os parâmetros
das funções necessárias à integração. Não inclui endereços de memória,
nomes de jogadores nem arquivos de save.

Se aparecer um erro na instalação ou no painel, envie a mensagem.
O instalador interrompe a atualização quando encontra arquivos próprios
modificados ou versões que ainda não foram analisadas.

Para retirar o teste, feche DD2 e execute **retirar-teste-runtime.cmd**
deste novo pacote. Somente os scripts próprios e inalterados são removidos.

Os testes feitos na nuvem usam Lua e PowerShell com dados sintéticos. A
observação no PC fornece a evidência do comportamento real; ela ainda não
valida as funcionalidades completas do mashup.
