﻿#Requires -Version 5.1
<#
.SYNOPSIS
Remove somente arquivos criados pelo instalador e que ainda possuem o mesmo hash.
.EXAMPLE
.\tools\remove-runtime-test.ps1 -WhatIf
.EXAMPLE
.\tools\remove-runtime-test.ps1 -GamePath 'D:\Games\Dragons Dogma 2'
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param([string]$GamePath)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageId = 'dogma-of-ash-runtime-install/v1'
$relativeFiles = @(
    'reframework/autorun/dogma_of_ash.lua',
    'reframework/autorun/dogma_of_ash/host.lua',
    'reframework/autorun/dogma_of_ash/domain.lua',
    'reframework/autorun/dogma_of_ash/observe.lua'
)
$receiptRelative = 'reframework/data/dogma_of_ash/runtime-install-receipt.json'

function Get-SteamLibraries {
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            foreach ($property in @('SteamPath', 'InstallPath')) {
                $value = $item.PSObject.Properties[$property]
                if ($null -ne $value -and $value.Value) { [void]$roots.Add([string]$value.Value) }
            }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { [void]$roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        [void]$libraries.Add([IO.Path]::GetFullPath($root))
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        foreach ($match in [regex]::Matches((Get-Content -Raw -LiteralPath $vdf), '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
            $candidate = $match.Groups['path'].Value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) { [void]$libraries.Add([IO.Path]::GetFullPath($candidate)) }
        }
    }
    foreach ($library in $libraries) { $library }
}

function Find-SteamInstall {
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($library in @(Get-SteamLibraries)) {
        $manifest = Join-Path $library 'steamapps/appmanifest_2054970.acf'
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        $match = [regex]::Match((Get-Content -Raw -LiteralPath $manifest), '"installdir"\s+"(?<dir>[^"\r\n]+)"')
        if (-not $match.Success) { continue }
        $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
        $candidate = [IO.Path]::GetFullPath((Join-Path $common $match.Groups['dir'].Value))
        if (-not $candidate.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { continue }
        if (Test-Path -LiteralPath (Join-Path $candidate 'DD2.exe') -PathType Leaf) { [void]$found.Add($candidate) }
    }
    foreach ($path in $found) { $path }
}

function Assert-SafeTarget([string]$Root, [string]$Target) {
    if (-not $Target.StartsWith($Root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destino fora do diretorio do DD2.' }
    $cursor = $Target
    while ($cursor -ne $Root) {
        $item = Get-Item -Force -LiteralPath $cursor -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link/junction no destino: $cursor. Nenhum arquivo sera removido." }
            if ($cursor -ne $Target -and -not $item.PSIsContainer) { throw "Um arquivo ocupa um diretorio esperado: $cursor" }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
        if (-not $cursor) { throw 'Destino invalido.' }
    }
}

if ($env:OS -ne 'Windows_NT') { throw 'Execute este desinstalador no Windows, no computador que possui Dragon''s Dogma 2.' }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Feche Dragon''s Dogma 2 antes de remover o diagnostico.' }
if (-not $GamePath) {
    $candidates = @(Find-SteamInstall)
    if ($candidates.Count -ne 1) { throw 'Nao foi encontrada uma unica instalacao Steam do DD2. Informe -GamePath apontando para a pasta de DD2.exe.' }
    $GamePath = $candidates[0]
}
$hostRoot = (Resolve-Path -LiteralPath $GamePath).ProviderPath.TrimEnd([IO.Path]::DirectorySeparatorChar)
if (-not (Test-Path -LiteralPath (Join-Path $hostRoot 'DD2.exe') -PathType Leaf)) { throw '-GamePath deve apontar para a pasta de DD2.exe.' }
if (((Get-Item -Force -LiteralPath $hostRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Junction/link na pasta do jogo. Nenhum arquivo foi removido.' }
$receiptPath = [IO.Path]::GetFullPath((Join-Path $hostRoot $receiptRelative))
Assert-SafeTarget $hostRoot $receiptPath
if (-not (Test-Path -LiteralPath $receiptPath)) { Write-Host 'Nenhum recibo encontrado. Nada foi removido.'; return }
if (-not (Test-Path -LiteralPath $receiptPath -PathType Leaf)) { throw 'O caminho do recibo e um diretorio. Nada foi removido.' }
$receiptHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash
try { $receipt = Get-Content -Raw -LiteralPath $receiptPath | ConvertFrom-Json }
catch { throw 'Recibo invalido. Preserve-o e revise manualmente; nada foi removido.' }
if ($receipt.schema -ne $packageId -or -not ($receipt.files -is [array])) { throw 'Recibo desconhecido. Nada foi removido.' }
$seen = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$entries = @(
    foreach ($file in $receipt.files) {
        if ($relativeFiles -cnotcontains $file.path -or $file.sha256 -notmatch '^[0-9a-fA-F]{64}$' -or -not $seen.Add($file.path)) { throw 'Recibo contem entradas desconhecidas. Nada foi removido.' }
        $destination = [IO.Path]::GetFullPath((Join-Path $hostRoot $file.path))
        Assert-SafeTarget $hostRoot $destination
        [pscustomobject]@{ path = $file.path; hash = $file.sha256; destination = $destination }
    }
)

$removable = @(
    foreach ($entry in $entries) {
        if (-not (Test-Path -LiteralPath $entry.destination)) { continue }
        if ((Test-Path -LiteralPath $entry.destination -PathType Leaf) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ieq $entry.hash) { $entry }
        else { Write-Warning ('Arquivo alterado ou substituido sera preservado: ' + $entry.path) }
    }
)
Write-Host ('Arquivos proprios e inalterados a remover: ' + $removable.Count + '. O loader, mods preexistentes, logs, diagnosticos e saves serao preservados.')
if (-not $PSCmdlet.ShouldProcess($hostRoot, 'Remover apenas arquivos registrados com hashes inalterados')) { return }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'DD2 foi iniciado durante a verificacao. Feche o jogo e tente novamente.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash -ine $receiptHash) { throw 'O recibo mudou durante a verificacao. Nada foi removido.' }
foreach ($entry in $removable) {
    Assert-SafeTarget $hostRoot $entry.destination
    if ((Test-Path -LiteralPath $entry.destination -PathType Leaf) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ieq $entry.hash) { Remove-Item -LiteralPath $entry.destination }
    else { Write-Warning ('Arquivo mudou durante a verificacao e foi preservado: ' + $entry.path) }
}
$remaining = @($entries | Where-Object { Test-Path -LiteralPath $_.destination })
if ($remaining.Count -eq 0 -and (Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash -ieq $receiptHash) {
    Remove-Item -LiteralPath $receiptPath
    Write-Host 'Diagnostico removido. Diretorios e arquivos de usuario foram preservados.'
} else { Write-Warning 'Arquivos alterados ou recibo atualizado foram preservados. O recibo permanece para revisao manual.' }
