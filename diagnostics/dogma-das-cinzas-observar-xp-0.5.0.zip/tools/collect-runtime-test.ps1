﻿#Requires -Version 5.1
<#
.SYNOPSIS
Copia somente o JSON diagnostico conhecido para diagnostico-runtime.json junto ao pacote.
#>
[CmdletBinding()]
param([string]$GamePath)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
function Get-SteamLibraries {
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            foreach ($property in @('SteamPath', 'InstallPath')) {
                $value = $item.PSObject.Properties[$property]
                if ($null -ne $value -and $value.Value) { [void]$roots.Add([string]$value.Value) }
            }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { [void]$roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        [void]$libraries.Add([IO.Path]::GetFullPath($root))
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        $content = Get-Content -Raw -LiteralPath $vdf
        foreach ($match in [regex]::Matches($content, '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
            $candidate = $match.Groups['path'].Value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                [void]$libraries.Add([IO.Path]::GetFullPath($candidate))
            }
        }
    }
    foreach ($library in $libraries) { $library }
}

function Find-SteamInstall([string]$AppId) {
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($library in @(Get-SteamLibraries)) {
        $manifest = Join-Path $library ('steamapps/appmanifest_{0}.acf' -f $AppId)
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        $match = [regex]::Match((Get-Content -Raw -LiteralPath $manifest), '"installdir"\s+"(?<dir>[^"\r\n]+)"')
        if (-not $match.Success) { continue }
        $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
        $candidate = [IO.Path]::GetFullPath((Join-Path $common $match.Groups['dir'].Value))
        if (-not $candidate.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { continue }
        if (Test-Path -LiteralPath $candidate -PathType Container) { [void]$found.Add($candidate) }
    }
    foreach ($path in $found) { $path }
}

function Assert-SafeTarget([string]$Root, [string]$Target) {
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $Target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destino fora do diretorio do DD2.' }
    $cursor = $Target
    while ($cursor -ne $Root) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -Force -LiteralPath $cursor
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link/junction no destino: $cursor. Nenhum arquivo sera sobrescrito." }
            if ($cursor -ne $Target -and -not $item.PSIsContainer) { throw "Um arquivo ocupa o diretorio necessario: $cursor" }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
        if (-not $cursor) { throw 'Destino invalido.' }
    }
}


function Assert-DiagnosticValue($Value, [int]$Depth = 0) {
    if ($Depth -gt 20) { throw 'Diagnostico excede a profundidade conhecida.' }
    if ($null -eq $Value -or $Value -is [bool] -or $Value -is [ValueType]) { return }
    if ($Value -is [string]) {
        if ($Value.Length -gt 8192 -or $Value -match '(?i)(?:[a-z]:[\\/]|\\\\|(?:https?|file)://|/(?:Users|home|workspace|steamapps)/|\b(?:bearer\s|password\s*[:=]|api[_-]?key\s*[:=]))') { throw 'Diagnostico contem texto fora do formato permitido. Nenhum log ou caminho pessoal sera copiado.' }
        return
    }
    if ($Value -is [array]) { foreach ($item in $Value) { Assert-DiagnosticValue $item ($Depth + 1) }; return }
    if ($Value -is [pscustomobject]) {
        foreach ($property in $Value.PSObject.Properties) {
            if ($allowedKeys -cnotcontains $property.Name) { throw 'Diagnostico contem campos desconhecidos. Nada foi copiado.' }
            Assert-DiagnosticValue $property.Value ($Depth + 1)
        }
        return
    }
    throw 'Tipo de dado desconhecido no diagnostico.'
}
$allowedKeys = @('schema_version','stage','capture_token','state','lua_version','gameplay_mutations_enabled','runtime_gameplay_validated','framework','features','types','missing','player','main_pawn','game_build','gold','experience','unresolved','game_name','api_version','build_tag','build_commit','tdb_version','tdb_version_state','key','label','status','enabled','reason','role','level_state','character_type','status_context_type','level','manager_getter_state','distinct_from_main_pawn','progression','name','present','required_methods','required_fields','methods','fields','descriptors_only','truncated','selector','descriptor','signature','parameter_count','parameter_types','parameter_types_available','return_type','is_static','static_metadata_available','type','kind','member','param_names','param_names_available','declaring_type','exp','exp_state','job','context_type','current_job_state','current_job','consumable_exp_state','consumable_exp','cumulative_exp_state','cumulative_exp','value','observation','before','after','active','hook_installed','source','argument_semantics','parameter_names','event_count_total','event_count_retained','discarded_count','ignored_count','error_count','timecounter','events','xp','jobpoints')
if ($env:OS -ne 'Windows_NT') { throw 'Execute este coletor no Windows. Ele copia somente o diagnostico SDK, sem alterar o jogo.' }
if (-not $GamePath) {
    $candidates = @(Find-SteamInstall '2054970' | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'DD2.exe') -PathType Leaf })
    if ($candidates.Count -ne 1) { throw 'Informe -GamePath apontando para a pasta de DD2.exe; nao foi encontrada uma unica instalacao Steam.' }
    $GamePath = $candidates[0]
}
$hostRoot = (Resolve-Path -LiteralPath $GamePath).ProviderPath.TrimEnd([IO.Path]::DirectorySeparatorChar)
if (-not (Test-Path -LiteralPath (Join-Path $hostRoot 'DD2.exe') -PathType Leaf)) { throw '-GamePath deve conter DD2.exe.' }
if (((Get-Item -Force -LiteralPath $hostRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Junction/link na pasta do jogo. Nada foi copiado.' }
$source = [IO.Path]::GetFullPath((Join-Path $hostRoot 'reframework/data/dogma_of_ash/diagnostics.json'))
Assert-SafeTarget $hostRoot $source
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw 'Diagnostico ainda nao exportado. No painel Dogma of Ash, capture e exporte o diagnostico primeiro.' }
if ((Get-Item -LiteralPath $source).Length -gt 4194304) { throw 'Diagnostico excede o limite de 4 MB. Nada foi copiado.' }
$bytes = [IO.File]::ReadAllBytes($source)
try { $diagnostic = [Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json }
catch { throw 'JSON diagnostico invalido. Nada foi copiado.' }
if ($diagnostic.schema_version -ne 1 -or $diagnostic.stage -cne 'diagnostic_source' -or -not ($diagnostic.gameplay_mutations_enabled -is [bool]) -or $diagnostic.gameplay_mutations_enabled -ne $false -or -not ($diagnostic.runtime_gameplay_validated -is [bool]) -or $diagnostic.runtime_gameplay_validated -ne $false -or $diagnostic.capture_token -notmatch '^\d+-\d+:\d+$') { throw 'O arquivo nao corresponde ao diagnostico SDK conhecido. Nada foi copiado.' }
Assert-DiagnosticValue $diagnostic
$output = Join-Path (Split-Path -Parent $PSScriptRoot) 'diagnostico-runtime.json'
if (Test-Path -LiteralPath $output) {
    $outputItem = Get-Item -Force -LiteralPath $output
    if ($outputItem.PSIsContainer -or ($outputItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'O destino do relatorio nao e um arquivo regular. Nada foi copiado.' }
    try { $previous = Get-Content -Raw -LiteralPath $output | ConvertFrom-Json }
    catch { throw 'diagnostico-runtime.json existente nao reconhecido. Preserve-o antes de repetir.' }
    if ($previous.schema_version -ne 1 -or $previous.stage -cne 'diagnostic_source') { throw 'diagnostico-runtime.json existente nao reconhecido. Preserve-o antes de repetir.' }
}
# Export only the validated object. Duplicate JSON properties or discarded
# raw text must not carry personal data into the file sent to the creator.
[IO.File]::WriteAllText($output, ($diagnostic | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
Write-Host 'diagnostico-runtime.json copiado junto ao pacote. Envie esse arquivo para verificar o SDK.'
Write-Host 'Nenhuma DLL, save, log ou arquivo do jogo foi alterado.'
