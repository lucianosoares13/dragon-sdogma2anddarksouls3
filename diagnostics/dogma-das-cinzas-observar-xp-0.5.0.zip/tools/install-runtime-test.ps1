﻿#Requires -Version 5.1
<#
.SYNOPSIS
Instala somente quatro Lua de diagnostico, usando o loader que voce ja possui.
.EXAMPLE
.\tools\install-runtime-test.ps1 -WhatIf
.EXAMPLE
.\tools\install-runtime-test.ps1 -GamePath 'D:\Games\Dragons Dogma 2'
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]$GamePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$packageId = 'dogma-of-ash-runtime-install/v1'
$hostExeHash = '29cbb3db102a8c8dba749f608928573e17d85fd9bdbaf3043abeccf911b0a836'
$existingLoaderHash = '8f005288fb1cded7c36dc834480125a824b3946b075caf15557e06d524d753bd'
$relativeFiles = @(
    'reframework/autorun/dogma_of_ash.lua',
    'reframework/autorun/dogma_of_ash/host.lua',
    'reframework/autorun/dogma_of_ash/domain.lua',
    'reframework/autorun/dogma_of_ash/observe.lua'
)
# Unica versao anterior permitida: manifest.json do ZIP imutavel 0.4.0.
# Nunca leia esses pins de um manifesto anterior fornecido pelo usuario.
$previousLuaHashes = @{
    'reframework/autorun/dogma_of_ash.lua' = '8a16a7673ddb0161a9ee5df484d75562559d175cc0aae19b6fdb5e16e4ebc359'
    'reframework/autorun/dogma_of_ash/host.lua' = '3cf185c1e6f6e78b1806d313c1f0f5cebcb3f76a70cff4b49322786297d83c7c'
    'reframework/autorun/dogma_of_ash/domain.lua' = '3acc79676f8e25633cdd4304db677e133a65677eea4cc2836039573cca4e25b3'
}
$receiptRelative = 'reframework/data/dogma_of_ash/runtime-install-receipt.json'

function Get-SteamLibraries {
    $roots = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            foreach ($property in @('SteamPath', 'InstallPath')) {
                $value = $item.PSObject.Properties[$property]
                if ($null -ne $value -and $value.Value) { [void]$roots.Add([string]$value.Value) }
            }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) {
        if ($base) { [void]$roots.Add((Join-Path $base 'Steam')) }
    }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
        [void]$libraries.Add([IO.Path]::GetFullPath($root))
        $vdf = Join-Path $root 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        $content = Get-Content -Raw -LiteralPath $vdf
        foreach ($match in [regex]::Matches($content, '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
            $candidate = $match.Groups['path'].Value.Replace('\\', '\')
            if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                [void]$libraries.Add([IO.Path]::GetFullPath($candidate))
            }
        }
    }
    foreach ($library in $libraries) { $library }
}

function Find-SteamInstall([string]$AppId) {
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($library in @(Get-SteamLibraries)) {
        $manifest = Join-Path $library ('steamapps/appmanifest_{0}.acf' -f $AppId)
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        $match = [regex]::Match((Get-Content -Raw -LiteralPath $manifest), '"installdir"\s+"(?<dir>[^"\r\n]+)"')
        if (-not $match.Success) { continue }
        $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
        $candidate = [IO.Path]::GetFullPath((Join-Path $common $match.Groups['dir'].Value))
        if (-not $candidate.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) { continue }
        if (Test-Path -LiteralPath $candidate -PathType Container) { [void]$found.Add($candidate) }
    }
    foreach ($path in $found) { $path }
}

function Get-BytesHash([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}

function Assert-SafeTarget([string]$Root, [string]$Target) {
    $prefix = $Root.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
    if (-not $Target.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) { throw 'Destino fora do diretorio do DD2.' }
    $cursor = $Target
    while ($cursor -ne $Root) {
        # Get-Item tambem reconhece links cujo destino deixou de existir.
        $item = Get-Item -Force -LiteralPath $cursor -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Link/junction no destino: $cursor. Nenhum arquivo sera sobrescrito." }
            if ($cursor -ne $Target -and -not $item.PSIsContainer) { throw "Um arquivo ocupa o diretorio necessario: $cursor" }
        }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
        if (-not $cursor) { throw 'Destino invalido.' }
    }
}

function Restore-InstallerBackup([string]$Root, [string]$Destination, [string]$Backup, [string]$InstalledHash) {
    # Mantenha o backup original ate confirmar o conteudo deslocado pelo rollback.
    Assert-SafeTarget $Root $Destination
    Assert-SafeTarget $Root $Backup
    $bytes = [IO.File]::ReadAllBytes($Backup)
    $restoreHash = Get-BytesHash $bytes
    $restorePath = $Destination + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    $restoreCreated = $false
    try {
        Assert-SafeTarget $Root $restorePath
        $stream = [IO.File]::Open($restorePath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $restoreCreated = $true
        try { $stream.Write($bytes, 0, $bytes.Length); $stream.Flush() }
        finally { $stream.Dispose() }
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $restorePath).Hash -ine $restoreHash) { throw 'Falha ao verificar o Lua/recibo preparado para restauracao.' }
        $displacedPath = $Destination + '.' + [Guid]::NewGuid().ToString('N') + '.bak'
        Assert-SafeTarget $Root $displacedPath
        if (Test-Path -LiteralPath $displacedPath) { throw 'Colisao no backup de rollback.' }
        Assert-SafeTarget $Root $Destination
        if (-not (Test-Path -LiteralPath $Destination -PathType Leaf) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash -ine $InstalledHash) {
            Write-Warning ('Alteracao externa preservada; backup anterior guardado para revisao: ' + $Backup)
            return
        }
        [IO.File]::Replace($restorePath, $Destination, $displacedPath)
        $restoreCreated = $false
        Assert-SafeTarget $Root $displacedPath
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $displacedPath).Hash -ine $InstalledHash) {
            # Uma edicao entre o hash e Replace tambem precisa ser preservada.
            $raceBackup = $Destination + '.' + [Guid]::NewGuid().ToString('N') + '.bak'
            Assert-SafeTarget $Root $raceBackup
            Assert-SafeTarget $Root $Destination
            if (-not (Test-Path -LiteralPath $raceBackup) -and
                (Test-Path -LiteralPath $Destination -PathType Leaf) -and
                (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash -ieq $restoreHash) {
                [IO.File]::Replace($displacedPath, $Destination, $raceBackup)
                Assert-SafeTarget $Root $raceBackup
                if ((Get-FileHash -Algorithm SHA256 -LiteralPath $raceBackup).Hash -ieq $restoreHash) { Remove-Item -LiteralPath $raceBackup }
                else { Write-Warning ('Outra alteracao externa foi capturada para revisao: ' + $raceBackup) }
            } else { Write-Warning ('Alteracao externa capturada para revisao: ' + $displacedPath) }
            Write-Warning ('Alteracao externa durante rollback preservada; backup anterior guardado: ' + $Backup)
            return
        }
        Assert-SafeTarget $Root $Backup
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $Backup).Hash -ieq $restoreHash) { Remove-Item -LiteralPath $Backup }
        else { Write-Warning ('Backup alterado externamente foi preservado: ' + $Backup) }
        Assert-SafeTarget $Root $displacedPath
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $displacedPath).Hash -ieq $InstalledHash) { Remove-Item -LiteralPath $displacedPath }
        else { Write-Warning ('Backup do rollback alterado externamente foi preservado: ' + $displacedPath) }
    } finally {
        if ($restoreCreated) {
            try {
                Assert-SafeTarget $Root $restorePath
                if (Test-Path -LiteralPath $restorePath -PathType Leaf) { Remove-Item -LiteralPath $restorePath }
            } catch { Write-Warning ('Temporario de restauracao preservado: ' + $restorePath + '; ' + $_.Exception.Message) }
        }
    }
}

if ($env:OS -ne 'Windows_NT') { throw 'Execute este instalador no Windows, no computador que possui Dragon''s Dogma 2.' }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Feche Dragon''s Dogma 2 antes de instalar.' }

if (-not $GamePath) {
    $candidates = @(Find-SteamInstall '2054970' | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'DD2.exe') -PathType Leaf })
    if ($candidates.Count -ne 1) { throw 'Nao foi encontrada uma unica instalacao Steam do DD2. Informe -GamePath apontando para a pasta de DD2.exe.' }
    $GamePath = $candidates[0]
}
$hostRoot = (Resolve-Path -LiteralPath $GamePath).ProviderPath.TrimEnd([IO.Path]::DirectorySeparatorChar)
$hostExe = Join-Path $hostRoot 'DD2.exe'
if (-not (Test-Path -LiteralPath $hostExe -PathType Leaf)) { throw '-GamePath deve apontar para a pasta de DD2.exe.' }
if (((Get-Item -Force -LiteralPath $hostRoot).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Junction/link na pasta do jogo. Nenhum arquivo foi instalado.' }
Assert-SafeTarget $hostRoot $hostExe

$bundleRoot = Split-Path -Parent $PSScriptRoot
$manifestPath = Join-Path $bundleRoot 'manifest.json'
try { $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json }
catch { throw 'Manifesto do pacote ausente ou invalido. Nada foi instalado.' }
if ($manifest.schema -ne 'dogma-of-ash-runtime-package/v1' -or $manifest.hostExeSha256 -ine $hostExeHash -or $manifest.existingLoaderSha256 -ine $existingLoaderHash) { throw 'Manifesto nao corresponde a este teste e seus hashes fixos. Nada foi instalado.' }
$loaderPath = Join-Path $hostRoot 'dinput8.dll'
Assert-SafeTarget $hostRoot $loaderPath
if (-not (Test-Path -LiteralPath $loaderPath -PathType Leaf)) { throw 'O loader existente nao foi encontrado. Este pacote nao instala DLLs.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $hostExe).Hash -ine $hostExeHash) { throw 'DD2.exe difere da versao observada. Nenhum arquivo foi instalado; envie um novo diagnostico.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $loaderPath).Hash -ine $existingLoaderHash) { throw 'dinput8.dll difere do loader observado. Ele foi preservado; nenhum arquivo foi instalado.' }
$entries = @(
    foreach ($relative in $relativeFiles) {
        $sourceRelative = $relative
        $source = Join-Path $bundleRoot $sourceRelative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Bundle incompleto: $sourceRelative. Use o pacote completo." }
        $bytes = [IO.File]::ReadAllBytes($source)
        if ($bytes.Length -eq 0) { throw "Arquivo vazio no bundle: $sourceRelative" }
        $hash = Get-BytesHash $bytes
        $expected = $manifest.files.PSObject.Properties[$relative]
        if ($null -eq $expected -or $expected.Value -notmatch '^[0-9a-fA-F]{64}$' -or $hash -ine $expected.Value) { throw ('SHA-256 do Lua nao corresponde ao manifesto: ' + $relative) }
        [pscustomobject]@{ path = $relative; hash = $hash; bytes = $bytes; destination = [IO.Path]::GetFullPath((Join-Path $hostRoot $relative)); action = 'create'; oldHash = $null }
    }
)

$receiptPath = [IO.Path]::GetFullPath((Join-Path $hostRoot $receiptRelative))
Assert-SafeTarget $hostRoot $receiptPath
$previousReceipt = $null
$previousHash = $null
$owned = [Collections.Generic.Dictionary[string,string]]::new([StringComparer]::OrdinalIgnoreCase)
if (Test-Path -LiteralPath $receiptPath) {
    if (-not (Test-Path -LiteralPath $receiptPath -PathType Leaf)) { throw 'Um diretorio ocupa o caminho do recibo.' }
    $receiptBytes = [IO.File]::ReadAllBytes($receiptPath)
    $previousHash = Get-BytesHash $receiptBytes
    try { $previousReceipt = [Text.Encoding]::UTF8.GetString($receiptBytes) | ConvertFrom-Json }
    catch { throw 'Recibo existente invalido. Preserve-o e revise manualmente; a instalacao nao o sobrescrevera.' }
    if ($previousReceipt.schema -ne $packageId -or -not ($previousReceipt.files -is [array])) { throw 'Recibo existente nao reconhecido. Nenhum arquivo sera sobrescrito.' }
    foreach ($file in $previousReceipt.files) {
        if ($relativeFiles -cnotcontains $file.path -or $file.sha256 -notmatch '^[0-9a-fA-F]{64}$' -or $owned.ContainsKey($file.path)) { throw 'Recibo existente contem entradas desconhecidas.' }
        $expected = @($entries | Where-Object { $_.path -ceq $file.path })[0]
        if ($expected.hash -ine $file.sha256 -and (-not $previousLuaHashes.ContainsKey($file.path) -or $previousLuaHashes[$file.path] -ine $file.sha256)) {
            throw 'Recibo pertence a uma versao desconhecida do pacote. Somente arquivos proprios e inalterados da versao 0.4 podem ser atualizados.'
        }
        $owned.Add($file.path, $file.sha256)
    }
}

# Examine todos os conflitos antes de criar qualquer arquivo.
$conflicts = @(
    foreach ($entry in $entries) {
        Assert-SafeTarget $hostRoot $entry.destination
        if (Test-Path -LiteralPath $entry.destination) {
            if (-not (Test-Path -LiteralPath $entry.destination -PathType Leaf)) { $entry.path; continue }
            $currentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash
            if ($owned.ContainsKey($entry.path)) {
                if ($currentHash -ine $owned[$entry.path]) { $entry.path; continue }
                if ($currentHash -ieq $entry.hash) { $entry.action = 'none' }
                else { $entry.action = 'replace'; $entry.oldHash = $currentHash }
            } elseif ($currentHash -ieq $entry.hash) { $entry.action = 'none' }
            else { $entry.path }
        }
    }
)
if ($conflicts.Count -gt 0) {
    throw ('Conteudo diferente ja existe: ' + ($conflicts -join ', ') + '. Nada foi copiado. Preserve seus mods; este instalador nao os substitui.')
}

$missing = @($entries | Where-Object { $_.action -eq 'create' })
$upgrades = @($entries | Where-Object { $_.action -eq 'replace' })
Write-Host ('Host validado: DD2; versao ' + [Diagnostics.FileVersionInfo]::GetVersionInfo($hostExe).FileVersion)
Write-Host 'Hashes do DD2 e do loader existente conferidos. Nenhuma DLL sera instalada ou substituida.'
Write-Host ('Arquivos novos: ' + $missing.Count + '; atualizacoes proprias 0.4: ' + $upgrades.Count + '; arquivos identicos existentes: ' + ($entries.Count - $missing.Count - $upgrades.Count) + '.')
if ($missing.Count -eq 0 -and $upgrades.Count -eq 0 -and $previousReceipt) { Write-Host 'Instalacao identica ja existe. Nenhuma alteracao necessaria.'; return }
if (-not $PSCmdlet.ShouldProcess($hostRoot, 'Instalar/atualizar diagnostico DD2 e registrar somente arquivos proprios')) { return }
if (@(Get-Process -Name DD2 -ErrorAction SilentlyContinue).Count -gt 0) { throw 'DD2 foi iniciado durante a verificacao. Feche o jogo e tente novamente.' }

$created = [Collections.Generic.List[object]]::new()
$changed = [Collections.Generic.List[object]]::new()
$temporaryLua = [Collections.Generic.List[string]]::new()
$temporaryReceipt = $null
$receiptBackup = $null
$receiptReplaced = $false
$newReceiptHash = $null
$committed = $false
try {
    foreach ($entry in @($entries | Where-Object { $_.action -ne 'none' })) {
        Assert-SafeTarget $hostRoot $entry.destination
        [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($entry.destination))
        $temporaryPath = $entry.destination + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
        Assert-SafeTarget $hostRoot $temporaryPath
        $stream = [IO.File]::Open($temporaryPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $temporaryLua.Add($temporaryPath)
        try { $stream.Write($entry.bytes, 0, $entry.bytes.Length); $stream.Flush() }
        finally { $stream.Dispose() }
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temporaryPath).Hash -ine $entry.hash) { throw 'Falha ao verificar o Lua temporario. Instalacao cancelada.' }
        Assert-SafeTarget $hostRoot $entry.destination
        if ($entry.action -eq 'replace') {
            $backupPath = $entry.destination + '.' + [Guid]::NewGuid().ToString('N') + '.bak'
            Assert-SafeTarget $hostRoot $backupPath
            if (Test-Path -LiteralPath $backupPath) { throw 'Colisao no caminho do backup. Operacao cancelada.' }
            if (-not (Test-Path -LiteralPath $entry.destination -PathType Leaf) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ine $entry.oldHash) {
                throw ('Arquivo proprio mudou durante a instalacao: ' + $entry.path)
            }
            [IO.File]::Replace($temporaryPath, $entry.destination, $backupPath)
            $changed.Add([pscustomobject]@{ entry = $entry; backup = $backupPath })
            if ((Get-FileHash -Algorithm SHA256 -LiteralPath $backupPath).Hash -ine $entry.oldHash) {
                throw ('Arquivo proprio mudou durante a substituicao: ' + $entry.path)
            }
        } else {
            # Move nao substitui um destino criado entre o preflight e este ponto.
            [IO.File]::Move($temporaryPath, $entry.destination)
            $created.Add($entry)
        }
        [void]$temporaryLua.Remove($temporaryPath)
        $owned[$entry.path] = $entry.hash
    }
    foreach ($entry in $entries) {
        Assert-SafeTarget $hostRoot $entry.destination
        if (-not (Test-Path -LiteralPath $entry.destination -PathType Leaf) -or (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ine $entry.hash) {
            throw ('Arquivo mudou antes do registro final: ' + $entry.path)
        }
    }
    $receipt = [ordered]@{
        schema = $packageId
        installedAtUtc = [DateTime]::UtcNow.ToString('o')
        hostExeSha256 = $hostExeHash
        existingLoaderSha256 = $existingLoaderHash
        files = @(
            foreach ($relative in $relativeFiles) {
                if ($owned.ContainsKey($relative)) { [ordered]@{ path = $relative; sha256 = $owned[$relative] } }
            }
        )
    }
    Assert-SafeTarget $hostRoot $receiptPath
    [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($receiptPath))
    $receiptTemporaryPath = $receiptPath + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
    Assert-SafeTarget $hostRoot $receiptTemporaryPath
    $receiptBytes = [Text.UTF8Encoding]::new($false).GetBytes(($receipt | ConvertTo-Json -Depth 8))
    $newReceiptHash = Get-BytesHash $receiptBytes
    $stream = [IO.File]::Open($receiptTemporaryPath, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
    $temporaryReceipt = $receiptTemporaryPath
    try { $stream.Write($receiptBytes, 0, $receiptBytes.Length); $stream.Flush() }
    finally { $stream.Dispose() }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $temporaryReceipt).Hash -ine $newReceiptHash) { throw 'Falha ao verificar o recibo temporario.' }
    Assert-SafeTarget $hostRoot $receiptPath
    if ($previousReceipt) {
        $receiptBackupPath = $receiptPath + '.' + [Guid]::NewGuid().ToString('N') + '.bak'
        Assert-SafeTarget $hostRoot $receiptBackupPath
        if (Test-Path -LiteralPath $receiptBackupPath) { throw 'Colisao no caminho do backup do recibo. Operacao cancelada.' }
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $receiptPath).Hash -ine $previousHash) { throw 'O recibo mudou durante a instalacao. Operacao cancelada.' }
        [IO.File]::Replace($temporaryReceipt, $receiptPath, $receiptBackupPath)
        $receiptBackup = $receiptBackupPath
        $receiptReplaced = $true
        if ((Get-FileHash -Algorithm SHA256 -LiteralPath $receiptBackup).Hash -ine $previousHash) { throw 'O recibo mudou durante a substituicao. Operacao cancelada.' }
    } else { [IO.File]::Move($temporaryReceipt, $receiptPath) }
    $temporaryReceipt = $null
    $committed = $true
} finally {
    foreach ($temporaryPath in $temporaryLua) {
        try {
            Assert-SafeTarget $hostRoot $temporaryPath
            if (Test-Path -LiteralPath $temporaryPath -PathType Leaf) { Remove-Item -LiteralPath $temporaryPath }
        } catch { Write-Warning ('Temporario preservado para revisao: ' + $temporaryPath + '; ' + $_.Exception.Message) }
    }
    if ($temporaryReceipt) {
        try {
            Assert-SafeTarget $hostRoot $temporaryReceipt
            if (Test-Path -LiteralPath $temporaryReceipt -PathType Leaf) { Remove-Item -LiteralPath $temporaryReceipt }
        } catch { Write-Warning ('Recibo temporario preservado para revisao: ' + $temporaryReceipt + '; ' + $_.Exception.Message) }
    }
    if (-not $committed) {
        if ($receiptReplaced) {
            try {
                Assert-SafeTarget $hostRoot $receiptPath
                Assert-SafeTarget $hostRoot $receiptBackup
                if (Test-Path -LiteralPath $receiptBackup -PathType Leaf) {
                    Restore-InstallerBackup $hostRoot $receiptPath $receiptBackup $newReceiptHash
                } else { Write-Warning ('Backup do recibo ausente; revise manualmente: ' + $receiptBackup) }
            } catch { Write-Warning ('Recibo preservado para revisao; backup: ' + $receiptBackup + '; ' + $_.Exception.Message) }
        }
        foreach ($entry in $created) {
            try {
                Assert-SafeTarget $hostRoot $entry.destination
                if ((Test-Path -LiteralPath $entry.destination -PathType Leaf) -and (Get-FileHash -Algorithm SHA256 -LiteralPath $entry.destination).Hash -ieq $entry.hash) { Remove-Item -LiteralPath $entry.destination }
                elseif (Test-Path -LiteralPath $entry.destination) { Write-Warning ('Arquivo novo alterado externamente foi preservado: ' + $entry.path) }
            } catch { Write-Warning ('Arquivo novo preservado para revisao: ' + $entry.path + '; ' + $_.Exception.Message) }
        }
        for ($index = $changed.Count - 1; $index -ge 0; $index--) {
            $change = $changed[$index]
            try {
                Assert-SafeTarget $hostRoot $change.entry.destination
                Assert-SafeTarget $hostRoot $change.backup
                if (Test-Path -LiteralPath $change.backup -PathType Leaf) {
                    Restore-InstallerBackup $hostRoot $change.entry.destination $change.backup $change.entry.hash
                } else { Write-Warning ('Backup anterior ausente; revise manualmente: ' + $change.backup) }
            } catch { Write-Warning ('Nao foi possivel restaurar; backup anterior guardado para revisao: ' + $change.backup + '; ' + $_.Exception.Message) }
        }
    } else {
        if ($receiptBackup) {
            try {
                Assert-SafeTarget $hostRoot $receiptBackup
                if (Test-Path -LiteralPath $receiptBackup -PathType Leaf) { Remove-Item -LiteralPath $receiptBackup }
            } catch { Write-Warning ('Instalacao concluida; backup do recibo preservado para revisao: ' + $receiptBackup + '; ' + $_.Exception.Message) }
        }
        foreach ($change in $changed) {
            try {
                Assert-SafeTarget $hostRoot $change.backup
                if (Test-Path -LiteralPath $change.backup -PathType Leaf) { Remove-Item -LiteralPath $change.backup }
            } catch { Write-Warning ('Instalacao concluida; backup preservado para revisao: ' + $change.backup + '; ' + $_.Exception.Message) }
        }
    }
}
Write-Host 'Diagnostico instalado. Inicie DD2 normalmente; o pacote nao altera saves, atributos, lojas, combate ou assets.'
Write-Host 'Para remover: execute tools\remove-runtime-test.ps1 com o mesmo -GamePath, se utilizado.'
