﻿#Requires -Version 5.1
<#
.SYNOPSIS
Coleta somente leitura da revisao e dos cabecalhos do loader existente.
.EXAMPLE
.\tools\collect-loader.ps1 -GamePath 'D:\Games\Dragons Dogma 2'
#>
[CmdletBinding()]
param([string]$GamePath)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$schema = 'dogma-of-ash-loader-probe/v1'
$issues = [Collections.Generic.List[string]]::new()

function Find-HostDirectory {
    $steam = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($key in @('HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam')) {
        $item = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($null -ne $item) {
            foreach ($name in @('SteamPath', 'InstallPath')) {
                $value = $item.PSObject.Properties[$name]
                if ($null -ne $value -and $value.Value) { [void]$steam.Add([string]$value.Value) }
            }
        }
    }
    foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles)) { if ($base) { [void]$steam.Add((Join-Path $base 'Steam')) } }
    $libraries = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($path in $steam) {
        if (-not (Test-Path -LiteralPath $path -PathType Container)) { continue }
        [void]$libraries.Add($path)
        $vdf = Join-Path $path 'steamapps/libraryfolders.vdf'
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        try {
            foreach ($match in [regex]::Matches((Get-Content -Raw -LiteralPath $vdf), '"(?:path|\d+)"\s+"(?<path>[^"\r\n]+)"')) {
                $candidate = $match.Groups['path'].Value.Replace('\\', '\')
                if ([IO.Path]::IsPathRooted($candidate) -and (Test-Path -LiteralPath $candidate -PathType Container)) { [void]$libraries.Add($candidate) }
            }
        } catch { $issues.Add('steamLibraryListUnreadable') }
    }
    $found = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($library in $libraries) {
        $manifest = Join-Path $library 'steamapps/appmanifest_2054970.acf'
        if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { continue }
        try {
            $match = [regex]::Match((Get-Content -Raw -LiteralPath $manifest), '"installdir"\s+"(?<dir>[^"\r\n]+)"')
            if (-not $match.Success) { continue }
            $common = [IO.Path]::GetFullPath((Join-Path $library 'steamapps/common'))
            $candidate = [IO.Path]::GetFullPath((Join-Path $common $match.Groups['dir'].Value))
            if ($candidate.StartsWith($common.TrimEnd([IO.Path]::DirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -and (Test-Path -LiteralPath $candidate -PathType Container)) { [void]$found.Add($candidate) }
        } catch { $issues.Add('steamManifestUnreadable') }
    }
    foreach ($path in $found) { $path }
}

function Get-Metadata([string]$Path, [string]$RelativeName) {
    $item = Get-Item -LiteralPath $Path
    $result = [ordered]@{ relativeName = $RelativeName; sizeBytes = $item.Length; creationUtc = $item.CreationTimeUtc.ToString('o'); lastWriteUtc = $item.LastWriteTimeUtc.ToString('o'); sha256 = $null; fileVersion = $null; productVersion = $null; authenticodeStatus = 'unavailable' }
    try { $result.sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }
    catch { $issues.Add('hashUnreadable-' + $RelativeName) }
    try { $version = [Diagnostics.FileVersionInfo]::GetVersionInfo($Path); $result.fileVersion = $version.FileVersion; $result.productVersion = $version.ProductVersion }
    catch { $issues.Add('fileVersionUnreadable-' + $RelativeName) }
    if (Get-Command Get-AuthenticodeSignature -ErrorAction SilentlyContinue) {
        try { $result.authenticodeStatus = [string](Get-AuthenticodeSignature -LiteralPath $Path).Status }
        catch { $issues.Add('signatureStatusUnavailable-' + $RelativeName) }
    }
    $result
}

function Read-Head([string]$Path, [int]$MaximumBytes) {
    $stream = [IO.File]::Open($Path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    try {
        $bytes = [byte[]]::new($MaximumBytes)
        $count = $stream.Read($bytes, 0, $bytes.Length)
        [Text.Encoding]::UTF8.GetString($bytes, 0, $count).TrimStart([char]0xFEFF)
    } finally { $stream.Dispose() }
}

function Get-RevisionEvidence([string]$Path, [string]$RelativeName) {
    $item = Get-Item -LiteralPath $Path
    $result = [ordered]@{ relativeName = $RelativeName; lastWriteUtc = $item.LastWriteTimeUtc.ToString('o'); classification = 'historicalEvidenceOnly'; status = 'unrecognized'; gitCommit = $null; releaseTag = $null }
    if ($item.Length -gt 4096) { $result.status = 'overReadLimit'; return $result }
    $text = (Read-Head $Path 4096).Trim()
    $commit = [regex]::Match($text, '(?im)^(?:\s*(?:git\s*(?:commit|sha)|commit|revision|hash)\s*[:=]\s*)?(?<value>[0-9a-f]{40})\s*$')
    $tag = [regex]::Match($text, '(?im)^(?:\s*(?:release|tag|version)\s*[:=]\s*)?(?<value>v\d+(?:\.\d+){2,3}|latest)\s*$')
    if ($commit.Success) { $result.gitCommit = $commit.Groups['value'].Value.ToLowerInvariant(); $result.status = 'recognizedText' }
    if ($tag.Success) { $result.releaseTag = $tag.Groups['value'].Value; $result.status = 'recognizedText' }
    $result
}

function Get-LogEvidence([string]$Path, [string]$RelativeName) {
    $item = Get-Item -LiteralPath $Path
    $evidence = [Collections.Generic.List[object]]::new()
    $seen = [Collections.Generic.HashSet[string]]::new()
    foreach ($line in ((Read-Head $Path 65536) -split '\r?\n' | Select-Object -First 512)) {
        $fields = @()
        if ($line -match '(?i)\bAPI\b') {
            $match = [regex]::Match($line, '(?i)\bAPI\s*(?:version)?\s*[:=]?\s*v?(?<value>\d+(?:\.\d+){1,3})\b')
            if ($match.Success) { $fields += [ordered]@{ field = 'apiVersion'; value = $match.Groups['value'].Value; interpretation = 'apiVersionNotRelease' } }
        } elseif ($line -match '(?i)\bREFramework\b') {
            $match = [regex]::Match($line, '(?i)\bREFramework\b[^\r\n]{0,40}?(?:\bversion\s*[:=]?\s*|\s+v)(?<value>\d+(?:\.\d+){1,3})\b')
            if ($match.Success) { $fields += [ordered]@{ field = 'frameworkVersionText'; value = $match.Groups['value'].Value; interpretation = 'unverifiedTextNotReleaseAttribution' } }
        }
        # Rotulos do cabecalho upstream; somente o valor estrito e exportado.
        $headerPrefix = '(?i)(?:^\s*|\]\s*)(?:REFramework\s+)?'
        foreach ($spec in @(
            @('frameworkCommitText', '(?:commit\s+hash|commit|revision|git\s*sha)\s*[:=]\s*(?<value>[0-9a-f]{7,40})\b'),
            @('frameworkTagText', '(?:release|tag)\s*[:=]\s*(?<value>v\d+(?:\.\d+){2,3}|latest)\b'),
            @('commitsPastTag', 'commits\s+past\s+tag\s*[:=]\s*(?<value>\d{1,9})\b'),
            @('buildDate', 'build\s+date\s*[:=]\s*(?<value>(?:0[1-9]|[12]\d|3[01])\.(?:0[1-9]|1[0-2])\.\d{4})\b'),
            @('buildTime', 'build\s+time\s*[:=]\s*(?<value>(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?)\b')
        )) {
            $match = [regex]::Match($line, $headerPrefix + $spec[1])
            if ($match.Success) {
                $value = $match.Groups['value'].Value
                if ($spec[0] -eq 'frameworkCommitText') { $value = $value.ToLowerInvariant() }
                $fields += [ordered]@{ field = $spec[0]; value = $value; interpretation = 'unverifiedLocalEvidence' }
            }
        }
        foreach ($spec in @(@('tdbVersion', '(?i)\bTDB\s*(?:version)?\s*[:=]?\s*(?<value>\d{1,4})\b'), @('luaVersion', '(?i)\bLua\s*(?:version)?\s*[:=]?\s*(?<value>\d+(?:\.\d+){1,3})\b'))) {
            $match = [regex]::Match($line, $spec[1])
            if ($match.Success) { $fields += [ordered]@{ field = $spec[0]; value = $match.Groups['value'].Value; interpretation = 'historicalHeaderText' } }
        }
        if ($line -match '(?i)\b(?:DD2|DD2DA|Dragon.s\s+Dogma\s+2)\b' -and $line -match '(?i)\b(?:game|REFramework|identity|detected|DD2)\b') { $fields += [ordered]@{ field = 'gameIdentity'; value = 'DD2'; interpretation = 'historicalHeaderText' } }
        foreach ($field in $fields) { if ($seen.Add($field.field + ':' + $field.value)) { $evidence.Add($field) } }
    }
    [ordered]@{ relativeName = $RelativeName; sizeBytes = $item.Length; lastWriteUtc = $item.LastWriteTimeUtc.ToString('o'); classification = 'historicalEvidenceOnly'; readLimitBytes = 65536; readLimitLines = 512; fields = @($evidence.ToArray()) }
}

if ($env:OS -ne 'Windows_NT') { throw 'Execute no Windows. Este coletor le o loader existente sem instala-lo ou substituir arquivos.' }
$hostRoot = $null
$discovery = 'steam'
if ($GamePath) {
    $discovery = 'explicitPath'
    try { if (Test-Path -LiteralPath $GamePath -PathType Container) { $hostRoot = (Resolve-Path -LiteralPath $GamePath).ProviderPath } else { $issues.Add('hostDirectoryUnavailable') } }
    catch { $issues.Add('hostDirectoryUnavailable') }
} else {
    $candidates = @(Find-HostDirectory)
    if ($candidates.Count -eq 1) { $hostRoot = $candidates[0] }
    else { $issues.Add($(if ($candidates.Count -gt 1) { 'multipleHostsRequireGamePath' } else { 'steamHostNotFound' })) }
}
$executables = @()
$loader = $null
$revisions = @()
$logs = @()
$missing = [Collections.Generic.List[string]]::new()
if ($hostRoot) {
    foreach ($name in @('DD2.exe', 'DD2DA.exe')) {
        $path = Join-Path $hostRoot $name
        if (Test-Path -LiteralPath $path -PathType Leaf) { try { $executables += Get-Metadata $path $name } catch { $issues.Add('executableMetadataUnreadable-' + $name) } }
    }
    if ($executables.Count -eq 0) { $issues.Add('recognizedHostExecutableNotFound') }
    $path = Join-Path $hostRoot 'dinput8.dll'
    if (Test-Path -LiteralPath $path -PathType Leaf) { try { $loader = Get-Metadata $path 'dinput8.dll' } catch { $issues.Add('loaderMetadataUnreadable') } }
    else { $missing.Add('dinput8.dll') }
    foreach ($name in @('reframework_revision.txt', 'reframework/reframework_revision.txt')) {
        $path = Join-Path $hostRoot $name
        if (Test-Path -LiteralPath $path -PathType Leaf) { try { $revisions += Get-RevisionEvidence $path $name } catch { $issues.Add('revisionUnreadable-' + $name) } }
        else { $missing.Add($name) }
    }
    foreach ($name in @('reframework.log', 're2_framework_log.txt', 'reframework/logs/reframework.log', 'reframework/reframework.log')) {
        $path = Join-Path $hostRoot $name
        if (Test-Path -LiteralPath $path -PathType Leaf) { try { $logs += Get-LogEvidence $path $name } catch { $issues.Add('logUnreadable-' + $name) } }
        else { $missing.Add($name) }
    }
}
$report = [ordered]@{ schema = $schema; collectedAtUtc = [DateTime]::UtcNow.ToString('o'); appId = '2054970'; discovery = $discovery; status = $(if ($issues.Count) { 'partial' } else { 'collected' }); hostExecutables = @($executables); existingLoader = $loader; revisionEvidence = @($revisions); logEvidence = @($logs); missingEvidenceFiles = @($missing.ToArray()); provenance = 'unknown'; compatibility = 'unknown'; historicalLogsDoNotEstablishCurrentState = $true; apiVersionDoesNotIdentifyRelease = $true; operations = [ordered]@{ gameFilesChanged = $false; loaderInstalledOrReplaced = $false; gameStarted = $false; savesRead = $false }; issues = @($issues | Select-Object -Unique) }
$output = Join-Path (Split-Path -Parent $PSScriptRoot) 'diagnostico-loader.json'
if (Test-Path -LiteralPath $output) {
    try { $previous = Get-Content -Raw -LiteralPath $output | ConvertFrom-Json }
    catch { throw 'diagnostico-loader.json existente nao reconhecido. Preserve-o antes de repetir.' }
    if ($previous.schema -ne $schema) { throw 'diagnostico-loader.json existente nao reconhecido. Preserve-o antes de repetir.' }
}
try { [IO.File]::WriteAllText($output, ($report | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false)) }
catch { throw 'Nao foi possivel gravar diagnostico-loader.json. Extraia o pacote em uma pasta gravavel.' }
Write-Host 'diagnostico-loader.json criado junto ao pacote. Envie esse arquivo para identificar o loader existente.'
Write-Host 'Nenhum arquivo do jogo foi alterado. Logs antigos sao apenas evidencia historica; compatibilidade continua desconhecida.'
