# Identificar o loader existente

Este pacote é um diagnóstico, ainda não é o mod jogável. Ele identifica o
loader já presente no PC para preparar o teste de integração com a expansão.

1. Extraia **todos** os arquivos do ZIP em uma nova pasta nos Downloads.
2. Dê dois cliques em **identificar-loader.cmd** na pasta extraída.
3. Ao aparecer “Concluído”, envie **diagnostico-loader.json**, criado nessa
   mesma pasta. Depois pode pressionar uma tecla para fechar a janela.

Não é necessário abrir nenhum dos jogos nem executar como administrador.
Se ocorrer um erro, envie uma foto da mensagem que permanece na janela.

## O que ele verifica

- Versão e hash do executável DD2 e do `dinput8.dll` existente.
- Revisão registrada e campos de versão nos cabeçalhos de logs conhecidos.
- Datas dos arquivos para distinguir registros históricos do estado atual.

O pacote não instala DLLs, não substitui o loader, não abre jogos e não lê
nem altera saves. Exporta apenas campos selecionados, sem caminhos completos,
nomes de jogadores ou conteúdo integral dos logs.

O iniciador verifica o hash exato do coletor antes de executá-lo. Usa
`RemoteSigned` apenas no processo temporário do PowerShell e desbloqueia
somente esse script verificado. Políticas definidas pelo administrador do
computador continuam sendo respeitadas.

Encontrar uma versão num log não comprova compatibilidade com a expansão.
O teste dentro do jogo só será preparado depois de avaliar essas evidências.
