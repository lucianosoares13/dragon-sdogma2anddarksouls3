@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "DOGMA_LOADER_PROBE_FILE=%~dp0tools\collect-loader.ps1"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; try { $p=$env:DOGMA_LOADER_PROBE_FILE; if ((Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne 'b4e442734ee929fdb79b9d5ea5083fcf094700b39a84872d69cf1b5730bf3d00') { throw 'O script foi alterado. Baixe e extraia o ZIP novamente.' }; Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop; Unblock-File -LiteralPath $p -ErrorAction Stop; & $p; exit 0 } catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }"
set "DOGMA_PROBE_EXIT=%ERRORLEVEL%"
if not "%DOGMA_PROBE_EXIT%"=="0" goto failed
echo.
echo Concluido. Envie diagnostico-loader.json, nesta mesma pasta.
goto finished
:failed
echo.
echo Nao foi possivel concluir. Envie uma foto do erro acima.
:finished
pause
exit /b %DOGMA_PROBE_EXIT%
